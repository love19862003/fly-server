/********************************************************************

  Filename:   NetManager

  Description:NetManager

  Version:  1.0
  Created:  31:3:2015   19:17
  Revison:  none
  Compiler: gcc vc

  Author:   wufan, love19862003@163.com

  Organization:
*********************************************************************/
#include "net/NetManager.h"
#include "net/NetSession.h"
#include "net/NetThread.h"
#include "net/NetCore.h"
#include "net/NetUV.h"
#include "net/NetObj.h"
#include "utility/MapTemplate.h"
#include "utility/Compress.h"
#include "utility/StringUtility.h"
#include <algorithm>
#include <set>
#include <thread>
#include <iostream>
#include <atomic>
#include <functional>
namespace ShareSpace {
  namespace NetSpace {

    typedef Utility::ObjPtrMap<SessionId, NetSession>  SessionMap;
    typedef Utility::ObjPtrMap<NetName, ObjectBase> NetSigMap;


    class NetService{
    private:
      NetService(const NetService&) = delete;
      NetService& operator = (const NetService&) = delete;
    public:
      enum ServiceState{
        _SERVICE_INIT_ = 0,
        _SERVICE_RUN_ = 1,
        _SERVICE_STOP_ = 2,
      };
      enum{
        _DEFAULT_BUFFER_SIZE = 65535,
      };


      explicit NetService(unsigned int c)
        : m_state(_SERVICE_INIT_)
        , m_currentId(INVALID_SESSION_ID)
        , m_workThreadCount(c){
        m_workThreadCount = c > 0 ? c : 1;
        m_sessions.setOptional(INVALID_SESSION_ID);
        m_nets.setOptional("");
      }
      virtual ~NetService(){
        m_threads.clear();
        m_sessions.clear();
        m_nets.clear();
      }
      //����һ���µĻỰ,���ҷ���һ��NetThread(��д)�߳�
      SessionPtr addNewSession(const Config& config, const FunMakeBlock& fun){
        ++m_currentId;
        return  SessionPtr(new NetSession(m_currentId, _DEFAULT_BUFFER_SIZE, config, fun));
      }
      //poll��Ϣ�����߳�
      bool poll(){
        //MYASSERT(m_state == NetServiceData::_SERVICE_RUN_);
        std::list<MessagePtr> msglist;
        std::list<SessionPtr> connectionDisConnSet;
        std::list<SessionPtr> connectionConnSet;
        for(auto& t : m_threads){
          t->pollThread(msglist, connectionConnSet, connectionDisConnSet);
        }
        for(auto& s : connectionConnSet){
          auto obj = m_nets.getData(s->netName());
          MYASSERT(obj);
          if(obj->allow(s)){
            m_sessions.addData(s->id(), s);
            obj->connect(s->id());
          } else{
            realKick(s);
          }
        }

        for(auto& m : msglist){
          auto s = m_sessions.getData(m->session());
          if(s){
            auto obj = m_nets.getData(s->netName());
            MYASSERT(obj);
            obj->call(m);
          }
        }

        for(auto& s : connectionDisConnSet){
          auto obj = m_nets.getData(s->netName());
          MYASSERT(obj);
          obj->close(s->id());
          m_sessions.eraseData(s->id());
          if(_CLIENT_FLAG_ == obj->type()){ m_nets.eraseData(s->netName()); }
        }

        return true;
      }

      void stop(unsigned int ms){
        if(_SERVICE_STOP_ == m_state){ return; }
        m_state = _SERVICE_STOP_;
        for(auto& t : m_threads){ t->stop(); }

        std::chrono::steady_clock::time_point clockBegin;
        std::chrono::steady_clock::time_point clockEnd;
        clockBegin = clockEnd = std::chrono::steady_clock::now();
        std::chrono::steady_clock::duration delay;

        do{
          poll();
          clockEnd = std::chrono::steady_clock::now();
          delay = std::chrono::duration_cast<std::chrono::milliseconds>(clockEnd - clockBegin);
        } while(delay.count() <= ms || check());
      }

      bool isRun() const{ return m_state == _SERVICE_RUN_; }

      bool setAllow(const NetName& name, const std::string& allow){
        auto obj = m_nets.getData(name);
        if(obj){
          return obj->setAllow(allow);
        }
        return false;
      }
      bool check() const{
        for(auto&t : m_threads){
          if(t->check()){ return true; }
        }
        return false;
      }
      //�����������ģ��
      bool start(){
        LOGDEBUG("uv:", uv_version_string());
        m_state = NetService::_SERVICE_RUN_;
        for(unsigned int i = 0; i < m_workThreadCount; ++i){
          m_threads.push_back(std::make_shared<NetThread>());
        }
        m_nets.forEach([this](const NetSigMap::pair_type& pair){
          auto p = pair.second;
          auto t = thread();
          p->bindThread(t);
        });
        for(auto& t : m_threads){
          t->start();
        }
        return true;
      }
      //ɾ��һ���ͻ������͵��������
      bool removeClient(const std::string& name){
        auto n = m_nets.getData(name);
        if(n && _CLIENT_FLAG_ == n->type()){
          for(auto& pair : m_sessions.constRefMap()){
            if(pair.second->netName() == name){
              return kick(pair.first);
            }
          }
        }
        return false;
      }


      //���߳�����
      bool kick(SessionId id){
        auto s = m_sessions.getData(id);
        return realKick(s);
      }
      //����һ���������
      bool add(const NetProperty& property){
        if(property.config().m_name.empty()){ return false; }
        if(m_nets.hasData(property.config().m_name)){ return false; }
        if(_SERVICE_STOP_ == m_state){ return false; }

        ObjectBase::FunCreateSession fun = std::bind(&NetService::addNewSession,
                                                     this,
                                                     std::placeholders::_1,
                                                     std::placeholders::_2);
        auto ptr = ObjectBase::create(property, fun);
        m_nets.addData(property.config().m_name, ptr);
        if(isRun()){ ptr->bindThread(thread()); }
        return true;
      }
      //������Ϣ
      bool send(const MessagePtr& msg){
        auto s = m_sessions.getData(msg->session());
        if(s){
          s->pushWrite(msg);
          return true;
        }
        return false;
      }
      //������Ϣ
      bool send(const NetName& name, const MessagePtr& msg){
        auto p = m_nets.getData(name);
        if(!p){ return false; }
        msg->lock(p->config().m_compress);
        for(auto& pair : m_sessions.constRefMap()){
          auto s = pair.second;
          if(s && s->netName() == name){
            MessagePtr ptr(msg->clone(s->id()));
            send(ptr);
          }
        }
        return true;
      }
    private:
      bool realKick(SessionPtr s){
        if(s){ return s->setKicked(); }
        return false;
      }
      ThreadPtr thread(){
        ThreadPtr t;
        size_t value = 0;
        for(auto& tt : m_threads){
          if(!t || value < tt->busy()){ t = tt; value = tt->busy(); }
        }
        return t;
      }

    protected:
      std::list<ThreadPtr> m_threads;             //�����̳߳�
      SessionMap m_sessions;
      NetSigMap m_nets;
      ServiceState m_state;                                     //����״̬
      std::atomic<SessionId> m_currentId;  //��һ��session id 
      unsigned int m_workThreadCount;                           //�����շ��߳�����
    };

    NetManager::NetManager(unsigned int t)
    :m_service(new NetService(t))
    { 
      ;
    }
    NetManager::~NetManager() {
      if(m_service) {
        m_service.reset();
      }
    }
    bool NetManager::start() {
      return m_service->start();
    }

    bool NetManager::add(const NetProperty& property) {
      return m_service->add(property);
    }
    bool NetManager::remove(const NetName& name) {
      return m_service->removeClient(name);
    }

    bool NetManager::poll() {
      return m_service->poll();
    }

    bool NetManager::send(const MessagePtr& msg) {
      return m_service->send(msg);
    }
    bool NetManager::send(const NetName& name, const MessagePtr& msg) {
      return m_service->send(name, msg);
    }

    bool NetManager::kick(const SessionId& id) {
      return m_service->kick(id);
    }

    bool NetManager::isRun() const {
      return m_service->isRun();
    }
    void NetManager::stop(unsigned int ms) {
      return m_service->stop(ms);
    }
    bool NetManager::setAllow(const NetName& name, const std::string& allow){
      return m_service->setAllow(name, allow);
    }
  }
}