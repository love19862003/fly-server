/********************************************************************
    Filename: NetObj.cpp
    Description:
    Version:  1.0
    Created:  13:4:2016   13:48
	
    Compiler: gcc vc
    Author:   wufan, love19862003@163.com
    Organization: lezhuogame
*********************************************************************/
#include "net/NetObj.h"
#include "net/NetThread.h"
#include "net/NetSession.h"
#include "utility/StringUtility.h"
namespace ShareSpace{
  namespace NetSpace{

    static void newConnectCall(uv_stream_t* server, int status);
    static void invaildTcpConnet(uv_handle_t* t){
      uv_tcp_t* tcp = (uv_tcp_t*)(t);
      podFree(tcp);
    }
    class TcpServer : public ObjectBase{
    public:
      explicit TcpServer(const NetProperty& property, FunCreateSession fun) : ObjectBase(property, fun){
        m_tcp = podMalloc<uv_tcp_t>() ;
        m_allow = property.config().m_allow;
        m_address = property.config().m_address;
        m_port = property.config().m_port;
        m_maxConnect = property.config().m_maxConnect;
      }
      virtual ~TcpServer(){
        if (m_tcp){
          podFree(m_tcp);
          m_tcp = nullptr;
        }
      }

      void sessionConnect(){
        uv_tcp_t*  tcp = podMalloc<uv_tcp_t>();
        int r = uv_tcp_init(m_tcp->loop, tcp);
        uvError("uv_tcp_init:", r);
        if(0 == uv_accept((uv_stream_t*)m_tcp, (uv_stream_t*)tcp)){
          struct sockaddr_in addr;
          int len = sizeof(sockaddr_in);
          r = uv_tcp_getpeername(tcp, (sockaddr*)&addr, &len);
          uvError("uv_tcp_getpeername:", r);
          auto s = cretaeSession();
          if(config().m_compress){s->setFlag(NetSession::SESSSION_COMPRESS);}
          auto t = thread();
          s->serverSession(tcp, 
                           addr,
                           std::bind(&NetThread::recvMsgList, t.get(), std::placeholders::_1, std::placeholders::_2),
                           std::bind(&NetThread::realSend, t.get()),
                           std::bind(&NetThread::notifyKick, t.get()),
                           std::bind(&NetThread::notifySend, t.get(), std::placeholders::_1));
          t->addSession(s);
        } else{
          uv_close((uv_handle_t*)tcp, invaildTcpConnet);
        }
      }

      virtual bool start() override{
        if (0 == (m_flag & _TAG_ADD )){
          return false;
        }
        m_flag &= (~_TAG_ADD);
        auto t = thread();
        uv_loop_t* loop = t->loop();
        m_tcp = podMalloc<uv_tcp_t>();
        m_tcp->data = this;
        struct sockaddr_in addr;
        int r = uv_ip4_addr(m_address.c_str(), m_port, &addr);
        uvError("uv_ip4_addr:", r);
        r = uv_tcp_init(loop, m_tcp);
        uvError("uv_tcp_init:", r);
        r = uv_tcp_bind(m_tcp, (const sockaddr*)&addr, 0);
        uvError("uv_tcp_bind:", r);
        r = uv_listen((uv_stream_t*)(m_tcp), m_maxConnect, newConnectCall);
        uvError("uv_listen:", r);
        return true;
      }
      virtual bool stop() override{
        uv_close((uv_handle_t*)m_tcp, nullptr);
        return true;
      }
      virtual bool allow(SessionPtr s)  override{
        if (m_allow.empty()){ return true;}
        return Utility::isPairIpAddress(s->remoteAddress(), m_allow);
      }
       virtual bool setAllow(const std::string& allow) override{ 
         m_allow = allow;
         return true;
       }
    protected:
    private:
       uv_tcp_t* m_tcp;
       std::string m_allow;
       std::string m_address;
       unsigned int m_port;
       unsigned int m_maxConnect;
    };

    void newConnectCall(uv_stream_t* server, int status){
      if(status == -1){ return; }
      TcpServer* s = static_cast<TcpServer*>(server->data);
      if(s){ s->sessionConnect(); }
    }


    class TcpClient : public ObjectBase{
    public:
      explicit TcpClient(const NetProperty& property, FunCreateSession fun): ObjectBase(property, fun){
        m_session = nullptr; 
      }
      virtual ~TcpClient(){
        m_session.reset();
      }
      virtual bool start() override{
        if(0 == (m_flag & _TAG_ADD)){
          return false;
        }

        if (nullptr == m_session){
          m_session = cretaeSession();
        }
        m_flag &= (~_TAG_ADD);
        auto t = thread();
        MYASSERT(t);
        MYASSERT(m_session);
        uv_tcp_t*  tcp = podMalloc<uv_tcp_t>();
        int r = uv_tcp_init(t->loop(), tcp);
        uvError("uv_tcp_init:", r);
        if(config().m_compress){m_session->setFlag(NetSession::SESSSION_COMPRESS);}
        struct sockaddr_in addr;
        r = uv_ip4_addr(config().m_address.c_str(), config().m_port, &addr);
        uvError("uv_ip4_addr:", r);
        m_session->clientSession(tcp,
                                 addr,
                                 std::bind(&NetThread::recvMsgList, t.get(), std::placeholders::_1, std::placeholders::_2),
                                 std::bind(&NetThread::realSend, t.get()),
                                 std::bind(&NetThread::notifyKick, t.get()),
                                 std::bind(&NetThread::notifySend, t.get(), std::placeholders::_1));
        t->addSession(m_session);
        return true;
      }
      virtual bool stop() override{
        m_session->clearFlag(NetSession::SESSION_RECONN);
        return true;
      }
      virtual bool allow(SessionPtr /*s*/) override{
        return true;
      }
       virtual bool setAllow(const std::string& /*allow*/) override {return true;}
    protected:
    private:
      SessionPtr m_session;
    };

    ObjectBase::ObjectBase(const NetProperty& property, FunCreateSession fun):m_property(property), m_fun(fun){
      m_flag |= _TAG_ADD;
    }
    ObjectBase::~ObjectBase(){

    }

    bool ObjectBase::bindThread(ThreadPtr t){
      m_thread = t;
      t->addObject(shared_from_this());
      return true;
    }

    ThreadPtr  ObjectBase::thread(){
      if(!m_thread.expired()){
        return m_thread.lock();
      } else{
        return nullptr;
      }
    }

    SessionPtr ObjectBase::cretaeSession(){ 
      return m_fun(m_property.config(), m_property.makeBlockFun()); 
    }

    ObjectPtr ObjectBase::create(const NetProperty& property, FunCreateSession fun){
      if (_SERVER_FLAG_ == property.config().m_serviceType){
        return std::make_shared<TcpServer>(property, fun);
      }
      if (_CLIENT_FLAG_ == property.config().m_serviceType){
        return std::make_shared<TcpClient>(property, fun);
      }
      MYASSERT(false);
      return nullptr;
    }


  }
}