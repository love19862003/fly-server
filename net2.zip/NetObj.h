/********************************************************************
    Filename: NetObj.h
    Description:
    Version:  1.0
    Created:  13:4:2016   12:07
	
    Compiler: gcc vc
    Author:   wufan, love19862003@163.com
    Organization: lezhuogame
*********************************************************************/
#ifndef __NetObj_H__
#define __NetObj_H__
#include "net/NetUV.h"
#include "net/NetCore.h"
namespace ShareSpace{
  namespace NetSpace{
    class ObjectBase : public std::enable_shared_from_this<ObjectBase>{
    public:
      typedef std::function<SessionPtr(const Config&, const FunMakeBlock& )> FunCreateSession;
      ObjectBase(const ObjectBase&) = delete;
      ObjectBase& operator = (const ObjectBase&) = delete;
      explicit ObjectBase(const NetProperty& property, FunCreateSession fun);
      virtual ~ObjectBase();

      static ObjectPtr create(const NetProperty& property, FunCreateSession fun);
      bool bindThread(ThreadPtr t);
      ThreadPtr  thread();
      SessionPtr cretaeSession();
      virtual bool start() = 0;
      virtual bool stop() = 0;
      virtual bool allow(SessionPtr s)  = 0;
      enum{
        _TAG_ADD = 0x00000001 << 0,
        _TAG_ALLOW = 0x00000001 << 1,
      };
      virtual bool setAllow(const std::string& allow) = 0;

      ServiceFlag  type() const {return m_property.config().m_serviceType; }

      void connect(SessionId id){ m_property.connectFun()(m_property.config().m_name, id);}
      void close(SessionId id){ m_property.closeFun()(m_property.config().m_name, id);}
      void call(MessagePtr m){ m_property.callFun()(m_property.config().m_name,m);}
      const Config& config() const{return m_property.config();}
    protected:
      unsigned int m_flag;           //��ʶ��
    private:
      NetProperty m_property;        //������Ϣ
      FunCreateSession m_fun;        //��������
      WeakThreadPtr m_thread;        //�����߳�
      
    };
  }
}
#endif // __NetObj_H__
