/********************************************************************
	Filename: 	NetSession.cpp
	Description:
	Version:  1.0
	Created:  31:3:2016   11:11
	
	Compiler: gcc vc
	Author:   wufan, love19862003@163.com
	Organization: lezhuogame
*********************************************************************/
#include "net/NetSession.h"
#include "net/NetThread.h"
#include "utility/Compress.h"
namespace ShareSpace {
  namespace NetSpace {
  
    /*static*/ void callWrite(uv_write_t* req, int status) {
      SessionPtr s = static_cast<NetSession*>(req->data)->shared_from_this();
      if (s){
        s->afterWrite(status);
      }
    }
    /*static*/ void callConnect(uv_connect_t* req, int status){
      SessionPtr s = static_cast<NetSession*>(req->data)->shared_from_this();
      if (s){
        s->connetResult(status);
      }
    }
    /*static*/ void callAlloc(uv_handle_t* handle, size_t len, uv_buf_t* buff) {
      SessionPtr s = static_cast<NetSession*>(handle->data)->shared_from_this();
      if(s) {
        s->allocReadBuffer(len, buff);
      }else{
        MYASSERT(false);
      }
    }
    /*static*/  void callRead(uv_stream_t* stream, ssize_t nread, const uv_buf_t* buf) {
      SessionPtr s = static_cast<NetSession*>(stream->data)->shared_from_this();
      if (s){
        s->afterRead(stream, nread, buf);
      }
    }
    /*static*/ void callShutDown(uv_shutdown_t* req, int /*status*/) {
      SessionPtr s = static_cast<NetSession*>(req->data)->shared_from_this();
      if(s) {
        s->close();
      }
    }
    /*static*/ void callClose(uv_handle_t* handle){
      SessionPtr s = (static_cast<NetSession*>(handle->data))->shared_from_this();
      if(s) { s->afterClose(); }
    }
    NetSession::NetSession(SessionId id,
                        size_t len,
                        const Config& config,
                        const FunMakeBlock& fun)
                        : m_sessionId(id)
                        , m_bufferSend(new NetBuffer(len))
                        , m_bufferRecv(new NetBuffer(len))
                        , m_waiteMessage(nullptr)
                        , m_ObjName(config.m_name)
                        ,m_makeBlockFun(fun){
      m_tcp = nullptr;
      m_connect = podMalloc<uv_connect_t>();
      m_write = podMalloc<uv_write_t>();
      m_shutDown = podMalloc<uv_shutdown_t>();

      m_connect->data = this;
      m_write->data = this;
      m_shutDown->data = this;
      if(config.m_autoReconnect) {setFlag(SESSION_RECONN);}
      m_flag = 0;
    }
    NetSession::~NetSession() {
      if(m_tcp){podFree(m_tcp); }
      podFree(m_connect);
      podFree(m_write);
      podFree(m_shutDown);

      m_bufferSend.reset();
      m_bufferRecv.reset();
      m_waiteMessage.reset();
    }

    bool NetSession::flag(unsigned int f) const{ 
      return (m_flag & f) > 0;
    }
    // set flag
    void NetSession::setFlag(unsigned int f){
     // LOGDEBUG(m_flag);
      m_flag |= f;
      //LOGDEBUG(m_flag);
    }
    //clear flag
    void NetSession::clearFlag(unsigned int f){
      //LOGDEBUG(m_flag);
      m_flag &= (~f);
      //LOGDEBUG(m_flag);
    }
    void NetSession::allocReadBuffer(size_t len, uv_buf_t* buff) {
      size_t ll = m_bufferRecv->maxLength() - m_bufferRecv->length();
      size_t l = std::min<size_t>(len, ll);
      uv_buf_t b = uv_buf_init(m_bufferRecv->writeData(), l);
      *buff = b;
    }
    MessagePtr NetSession::readMessage(){
      if(!m_waiteMessage) { m_waiteMessage = m_makeBlockFun(m_sessionId); }
      if(m_waiteMessage) {
        m_waiteMessage->recv(m_bufferRecv);
        if(m_waiteMessage->done()) {
          auto p = m_waiteMessage;
          MYASSERT(!p->error(), "crc32 check is error");
          m_waiteMessage = nullptr;
          return p;
        }
      }
      return nullptr;
    }
    bool NetSession::afterRead(uv_stream_t* stream, ssize_t nread, const uv_buf_t* buf) {
      if(nread >= 0 && buf && buf->base && buf->len > 0) {
        std::list<MessagePtr> list;
        size_t size = 0;
        m_bufferRecv->writeData(nread);
        while(m_bufferRecv->hasWrite()) {
          auto m = readMessage();
          if(m) {
            list.push_back(m);
            m_recvTotalCount++;
            m_recvTotalLen += m->length();
            size += m->length();
          } else { break; }
        }
        if (m_threadAfterRead){
          m_threadAfterRead(list, size);
          return true;
        }else{ 
          MYASSERT(false);
          return false; 
        }
      }
      int r = uv_shutdown(m_shutDown, stream, callShutDown);
      uvError("uv_shutdown:", r);
      return false;
    }
    void NetSession::read(){
      int r = uv_read_start((uv_stream_t*)m_tcp, callAlloc, callRead);
      uvError("begin read " + m_ObjName + " session:" + std::to_string(m_sessionId) + " r:", r);
      return;
    }
    void NetSession::connetResult(int status){
      if (0 == status){
        setFlag(SESSION_CONNECT);
        setFlag(SESSION_CALL_CONN);
        read();
      }else{
        LOGINFO("connect ", m_ObjName, " failed");
        if(flag(SESSION_RECONN)) {
          connectServer(); 
        } else {
          close(false); 
        }
      }
    }

    void NetSession::close( bool call){
      if (!call){clearFlag(SESSION_CONNECT);}
      uv_close((uv_handle_t*)m_tcp, call ? callClose : nullptr);
    }
    void NetSession::afterClose(){
      if (flag(SESSION_RECONN) ){
        m_waiteMessage.reset();
        m_bufferRecv->reset(true);
        m_bufferSend->reset(true);
        MYASSERT(false);
        connectServer();
        return ;
      }
      setFlag(SESSION_CAll_CLOS);
      clearFlag(SESSION_CONNECT);
    }
    void NetSession::clientSession(uv_tcp_t * tcp,
                                   const sockaddr_in& addr,
                                   const RecvCall& recvNotify,
                                   const WriteCall& writeNotify,
                                   const KickCall& kickNotify,
                                   const SendCall& sendNotify){
      m_addr = addr;
      m_tcp = tcp;
      m_tcp->data = this;
      m_ip = inet_ntoa(addr.sin_addr);
      m_threadAfterRead = recvNotify;
      m_threadAfterWrite = writeNotify;
      m_nofitySend = sendNotify;
      m_notifyKick = kickNotify;
      setFlag(SESSION_RECONN);
      connectServer();
    }
    bool NetSession::connectServer() {
      int r = uv_tcp_connect(m_connect, m_tcp, (const struct sockaddr*)&m_addr, callConnect);
      if(r != 0) { LOGDEBUG("connect ", m_ObjName, " error:", uv_err_name(r)); connectServer(); }
      return true;
    }
    bool NetSession::serverSession(uv_tcp_t* tcp, 
                                   const sockaddr_in& addr,
                                   const RecvCall& recvNotify,
                                   const WriteCall& writeNotify,
                                   const KickCall& kickNotify,
                                   const SendCall& sendNotify){
      m_tcp = tcp;
      m_tcp->data = this;
      m_addr = addr;
      m_ip = inet_ntoa(addr.sin_addr);
      m_threadAfterRead = recvNotify;
      m_threadAfterWrite = writeNotify;
      m_nofitySend = sendNotify;
      m_notifyKick = kickNotify;
      setFlag(SESSION_CONNECT);
      setFlag(SESSION_CALL_CONN);
      read();
      return true;
    }

    void NetSession::pushWrite(MessagePtr msg){
      msg->lock(flag(SESSSION_COMPRESS));
      ++m_sendTotalCount;
      if(m_nofitySend){ m_nofitySend(msg); }
    }
    bool NetSession::takeToWriteBuffer(MessagePtr m){
      if (flag(SESSION_SEND) || m_bufferSend->isFull()){return false;}
      m->readBuffer(*m_bufferSend);
      return true;
    }
    void NetSession::write(){
      uv_buf_t buf;
      buf.base = m_bufferSend->data();
      buf.len = m_bufferSend->length();
      int r = uv_write(m_write, (uv_stream_t*)m_tcp, &buf, 1, callWrite);
      uvError("uv_write:", r);
      setFlag(SESSION_SEND);
    }

    void NetSession::afterWrite(int status) {
      if(status > 0) {
        int r = uv_shutdown(m_shutDown, (uv_stream_t*)m_tcp, callShutDown);
        uvError("uv_shutdown:", r);
        return;
      }
      m_sendTotalLen += m_bufferSend->length();
      m_bufferSend->reset();
      clearFlag(SESSION_SEND);
      if (m_threadAfterWrite){
        m_threadAfterWrite();
      }else{MYASSERT(false); }
    }
    bool NetSession::setKicked(){
      setFlag(SESSION_KICK);
      clearFlag(SESSION_RECONN);
      if (m_notifyKick){
        m_notifyKick();
        return true;
      }
      MYASSERT(false);
      return false;
    }



    //////////////////////////////////////////////////////////////////////////
  }
}