/********************************************************************

  Filename:   NetUV

  Description:NetUV

  Version:  1.0
  Created:  31:3:2015   19:32
  Revison:  none
  Compiler: gcc vc

  Author:   wufan, love19862003@163.com

  Organization:
*********************************************************************/
#ifndef __NetUV_H__
#define __NetUV_H__
#include <functional>
#ifdef WIN32
#include "net/libuv/include/uv.h"
#include "net/libuv/src/queue.h"
#else
#include "uv.h"
#endif // WIN32

#include "log/MyLog.h"
#ifdef _DEBUG
#define uvError(info, e) if(e != 0){ LOGDEBUG(info, uv_strerror(e)); MYASSERT(false);}
//#define uvError(info, e) if(e != 0){ LOGDEBUG(info, uv_strerror(e), FILE_FUNTION_LINE);}
#else
#define uvError(info, e) if(e != 0){ LOGDEBUG(info, uv_strerror(e), FILE_FUNTION_LINE);}
#endif // _DEBUG

namespace ShareSpace {
  namespace NetSpace {

    class NetSession;
    class NetThread;
    typedef std::shared_ptr<NetSession> SessionPtr;
    typedef std::shared_ptr<NetThread> ThreadPtr;
    typedef std::weak_ptr<NetThread> WeakThreadPtr;

    // auto lock
    class NetGuardLock {
    public:
      explicit NetGuardLock(uv_mutex_t* t) :m_mutex(t) {
        uv_mutex_lock(m_mutex);
      }
      ~NetGuardLock() {
        uv_mutex_unlock(m_mutex);
      }
    protected:
    private:
      NetGuardLock(const NetGuardLock&) = delete;
      NetGuardLock& operator = (const NetGuardLock&) = delete;
    private:
      uv_mutex_t* m_mutex;
    };
  }
}
#endif