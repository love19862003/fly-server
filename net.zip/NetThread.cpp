/********************************************************************
	Filename: 	NetThread.cpp
	Description:
	Version:  1.0
	Created:  31:3:2016   10:48
	
	Compiler: gcc vc
	Author:   wufan, love19862003@163.com
	Organization: lezhuogame
*********************************************************************/
#include "net/NetThread.h"
#include "net/NetSession.h"
namespace ShareSpace {
  namespace NetSpace {
    static void callAsyncAddSession(uv_async_t* handle) {
      NetThread* p = static_cast<NetThread*>(handle->data); 
      if(p) { p->asyncAddSession(); }
    }
    static void callAsyncStopThread(uv_async_t* handle) {
      NetThread* p = static_cast<NetThread*>(handle->data);
      if(p) { p->asyncStopThread(); }
    }
    static void callAsyncKickSession(uv_async_t* handle) {
      NetThread* p = static_cast<NetThread*>(handle->data);
      if(p) { p->asyncKickSession(); }
    }
    static void callAsyncSendMessage(uv_async_t* handle) {
      NetThread* p = static_cast<NetThread*>(handle->data);
      if(p) { p->realSend(); }
    }

    static void closeThreadSync(uv_handle_t* /*handle*/) {
      LOGDEBUG("close work thread sync");
    }
                                    
    static void callThreadRun(void* p) {
      NetThread* t = static_cast<NetThread*>(p);
      if(t) { t->threadRun();}
    }
    

    NetThread::NetThread() : m_state(_INIT_), m_onlines(0) {
      m_loop = podMalloc<uv_loop_t>();
      m_loop->data = this;
      for(auto& m : m_mutexs) {
        uv_mutex_init(&m);
      }
      for(auto& a : m_asyncs) {
        a.data = this;
      }
    }
    NetThread::~NetThread() {
      podFree<uv_loop_t>(m_loop);
      m_loop = nullptr;
      m_kickList.clear();
      m_newList.clear();
      m_clientList.clear();
      m_stateList.clear();
      m_onlieList.clear();
      m_recvList.clear();
      m_sendList.clear();
      for(auto& m : m_mutexs) {
        uv_mutex_destroy(&m);
      }
    }

    size_t  NetThread::busy() const {
      return m_onlines > 0 ? (m_totalSendSize + m_totalRealRecv) / m_onlines : 0;
    }
    void  NetThread::stop() {
      int r = uv_async_send(&m_asyncs[NetThread::async_stop_thread]);
      uvError("uv_async_send:", r);
      m_state = _STOP_;
      r = uv_thread_join(&m_thread_work);
      uvError("uv_thread_join:", r);
    }
    void NetThread::createThread() {
      int r = uv_thread_create(&m_thread_work, callThreadRun, this);
      uvError("uv_thread_create:", r);
    }
    void NetThread::activeSession(SessionPtr s) {
      NetGuardLock lock(&m_mutexs[NetThread::mutex_session]);
      m_onlieList.insert(s);
      m_stateList.push_back(s);
    }
    void NetThread::closeSession(SessionPtr s){
      NetGuardLock lock(&m_mutexs[NetThread::mutex_session]);
      if (s->isClient()){m_clientList.erase(s);}
      m_onlines--;
      m_onlieList.erase(s);
      m_stateList.push_back(s);
    }
    bool NetThread::check() {
      NetGuardLock lock(&m_mutexs[NetThread::mutex_send]);
      return !m_sendList.empty();
    }
    bool NetThread::addSession(SessionPtr s) {
      NetGuardLock locker(&m_mutexs[NetThread::mutex_session]);
      m_newList.push_back(s);
      int r = uv_async_send(&m_asyncs[NetThread::async_add_session]);
      uvError("uv_async_send:", r);
      return true;
    }
    bool NetThread::addNewClient(SessionPtr s) {
     if (_RUN_ == m_state){
       return addSession(s);
     }else{
       m_clientList.insert(s);
       m_onlines++;
       return true;
     }
     
    }
    void NetThread::asyncAddSession(){
      if(m_state != _RUN_) { return; }
      NetGuardLock lock(&m_mutexs[NetThread::mutex_session]);
      m_onlines += m_newList.size();
      for(auto& s : m_newList) {
        if (s->isClient()){
          m_clientList.insert(s);
          s->initConnect();
        }else{
          s->read();
          activeSession(s);
        }
      }
      m_newList.clear();
    }
    void NetThread::asyncStopThread(){
      //���ͻ������Ϣ
      realSend();
      
      //�ر����ߵĻỰ
      std::set<SessionPtr> list;
      {
        NetGuardLock lock(&m_mutexs[NetThread::mutex_session]);
        list = m_onlieList;
        list.insert(m_newList.begin(), m_newList.end());
        // �ͻ�����������. û�������ϵĻ� ֱ�ӹر�
        for(auto& client : m_clientList) { 
          client->unReconn();
          if (0 == m_onlieList.count(client)){ client->close(false); }
        }
      }
      // �ر���������
      for(auto& s : list) { s->close(); }
      // �ر�async
      for(auto& v : m_asyncs) { uv_close((uv_handle_t*)&v, closeThreadSync); }
      // �ȵ����еĻỰ��ɺ�ر�loop
      int r = uv_loop_alive(m_loop);
      while(r == 0) {
        r = uv_loop_alive(m_loop);
        uv_stop(m_loop);
        LOGDEBUG("set work listen thread stop");
        break;
      }
    }
    void NetThread::asyncKickSession(){
      std::list<SessionPtr> list;
      {
        NetGuardLock lock(&m_mutexs[NetThread::mutex_session]);
        list = m_kickList;
        m_kickList.clear();
      }
      while(list.size() > 0) {
        SessionPtr s = list.front();
        list.pop_front();
        if(m_onlieList.count(s) > 0) {
          s->close();
        }
      }
    }

    void NetThread::threadRun(){
      int r = uv_loop_init(m_loop);
      uvError("uv_loop_init:", r);
      r = uv_async_init(m_loop, &m_asyncs[NetThread::async_add_session], callAsyncAddSession);
      uvError("uv_async_init:", r);
      r = uv_async_init(m_loop, &m_asyncs[NetThread::async_stop_thread], callAsyncStopThread);
      uvError("uv_async_init:", r);
      r = uv_async_init(m_loop, &m_asyncs[NetThread::async_kick_session], callAsyncKickSession);
      uvError("uv_async_init:", r);
      r = uv_async_init(m_loop, &m_asyncs[NetThread::async_send_message], callAsyncSendMessage);
      uvError("uv_async_init:", r);
      for(auto& s : m_clientList) { s->initConnect(); }
      m_state = _RUN_;
      r = uv_run(m_loop, UV_RUN_DEFAULT);
      uvError("uv_run:", r);
      r = uv_loop_close(m_loop);
      uvError("uv_loop_close:", r);
      m_clientList.clear();
      LOGDEBUG("exit net work thread");
    }

    void NetThread::recvMsgList(const std::list<MessagePtr>& list, size_t size) {
      NetGuardLock locker(&m_mutexs[NetThread::mutex_recive]);
      m_recvList.insert(m_recvList.end(), list.begin(), list.end());
      m_totalRealRecvCount += list.size();
      m_totalRealRecv += size;
    }
    void NetThread::realSend(){
      auto sessionFun = [&](SessionId id)->SessionPtr {
        auto it = std::find_if(m_onlieList.begin(), m_onlieList.end(), [id](const SessionPtr& s) { return s->id() == id; });
        if(it != m_onlieList.end()) { return  *it; }
        return nullptr;
      };
      std::set<SessionPtr> sset;
      sset.clear();
      NetGuardLock lock(&m_mutexs[NetThread::mutex_send]);
      if(m_sendList.empty()) { return; }
      auto it = m_sendList.begin();
      auto itEnd = m_sendList.end();
      while(it != itEnd) {
        auto& msg = *it;
        size_t size = msg->length();
        auto s = sessionFun(msg->session());
        if(!s) {
          it = m_sendList.erase(it);
          continue;
        }
        if(!s->isConnect()) {
          ++it;
          continue;
        }
       
        if (!s->fillWrite(msg)){
          ++it;
          continue;
        }
        sset.insert(s);
        if(msg->readComplete()) {
          it = m_sendList.erase(it);
          m_totalRealSendCount++;
          m_totalRealSendSize += size;
        } else {
          ++it;
        }
      }
      //read send
      for(auto& s : sset) { s->write(); }
    }

    bool NetThread::pollThread(std::list<MessagePtr>& msg, std::list<SessionPtr>& conn, std::list<SessionPtr>&dis){
      if (_RUN_ == m_state){
        {
          NetGuardLock locker(&m_mutexs[mutex_recive]);
          msg.insert(msg.end(),m_recvList.begin(), m_recvList.end());
          m_recvList.clear();
        }  
        {
          NetGuardLock locker(&m_mutexs[mutex_session]);
          for(auto& s : m_stateList) {
            if(s->isConnect()) {conn.push_back(s); }
            else { dis.push_back(s);}
          }
          m_stateList.clear();
        }
        return true;
      }
      return false;
    }


    void NetThread::pushWrite(MessagePtr msg){
      m_totalSendCount++;
      m_totalSendSize += msg->length();
      NetGuardLock locker(&m_mutexs[NetThread::mutex_send]);
      m_sendList.push_back(msg);
      int r = uv_async_send(&m_asyncs[NetThread::async_send_message]);
      uvError("uv_async_send:", r);
    }
    bool NetThread::kick(SessionPtr s){
      if(!s) { return false; }
      NetGuardLock lock(&m_mutexs[NetThread::mutex_session]);
      m_kickList.push_back(s);
      int r = uv_async_send(&m_asyncs[NetThread::async_kick_session]);
      uvError("uv_async_send:", r);
      return true;
    }
    //////////////////////////////////////////////////////////////////////////
    


  }
}