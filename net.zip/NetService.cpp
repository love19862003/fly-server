/********************************************************************

  Filename:   NetService

  Description:NetService

  Version:  1.0
  Created:  31:3:2015   19:27
  Revison:  none
  Compiler: gcc vc

  Author:   wufan, love19862003@163.com

  Organization:
*********************************************************************/
#include "net/NetService.h"
#include "net/NetSession.h"
#include "net/NetThread.h"
#include "net/NetCore.h"
#include "net/NetUV.h"
#include "utility/MapTemplate.h"
#include "utility/Compress.h"
#include "utility/StringUtility.h"
#include <algorithm>
#include <set>
#include "log/MyLog.h"
#include <thread>
#include <iostream>


namespace ShareSpace {
  namespace NetSpace {

    static void callService(void* p);
    static void callStopSercive(uv_async_t* handle);
    static void callAddNet(uv_async_t* handle);
    static void callSessionConnect(uv_stream_t* tcp, int status);
    static void callTcpServiceStop(uv_handle_t* handle);
    static void callCloseSync(uv_handle_t* /*handle*/) {
      std::cout<< "tid:" <<std::this_thread::get_id() << std::endl;
      LOGDEBUG("stop listen thread async"); 
    }
    


    class NetSignalData  {
    private:
      NetSignalData(const NetSignalData&) = delete;
      NetSignalData& operator = (const NetSignalData&) = delete;
    public:
      explicit NetSignalData(const NetConfig& c, NetServiceData* f, NetCallBackPtr call)
        : m_configs(c)
        , m_service(f)
        , m_tcp(nullptr)
        , m_calls(std::move(call)){
        if(isServerPeer()) {
          m_configs.m_autoReconnect = false;
        }
      }
      virtual ~NetSignalData() {
        m_calls.reset();
      }
      //�Ƿ��ǿͻ������Ӷ���
      bool isClientPeer() const {
        return  _CLIENT_FLAG_ ==  m_configs.m_serviceType;
      }
      //�Ƿ��Ƿ������˿����������
      bool isServerPeer() const{
        return _SERVER_FLAG_ == m_configs.m_serviceType;
      }
      //�����̼߳��IP����������
      bool sessionCheck(SessionPtr s) {
        if( isServerPeer() &&
            !m_configs.m_allow.empty() && 
            !Utility::isPairIpAddress(s->remoteAddress(), m_configs.m_allow)) {
          LOGDEBUG("handle session:", s->id(), " ip:", s->remoteAddress(), " not compare:", m_configs.m_allow);
          return false;
        }
        return true;
      }
      //close tcp 
      bool stop(){
        if(isServerPeer()) {
          uv_close((uv_handle_t*)m_tcp, callTcpServiceStop);
          return true;
        }
        return false;
      }
      //�������˿���������������󴴽�listenThread���������̵߳���
      bool listen(uv_loop_t* loop){
        if(!isServerPeer()) { return false; }
        m_tcp = podMalloc<uv_tcp_t>();
        m_tcp->data = this;
        struct sockaddr_in addr;
        int r = uv_ip4_addr(m_configs.m_address.c_str(), m_configs.m_port, &addr);
        uvError("uv_ip4_addr:", r);
        r = uv_tcp_init(loop, m_tcp);
        uvError("uv_tcp_init:", r);
        r = uv_tcp_bind(m_tcp, (const sockaddr*)&addr, 0);
        uvError("uv_tcp_bind:", r);
        r = uv_listen((uv_stream_t*)(m_tcp), m_configs.m_maxConnect, callSessionConnect);
        uvError("uv_listen:", r);
        return true;
      }
      //�ͻ�������������󴴽������͵��Լ��Ĵ���NetThread��д�߳�
      bool client();

      //���߳�poll����. ��ԻỰ���ӳɹ�
      bool connect(SessionId id) const{
        MYASSERT(m_calls);
        MYASSERT(m_calls->m_connectCall);
        m_calls->m_connectCall(m_configs.m_name, id);
        return true;
      }
      //���߳�poll����. ��ԻỰ�ر�
      bool close(SessionId id) const{
        MYASSERT(m_calls);
        MYASSERT(m_calls->m_closeCall);
        m_calls->m_closeCall(m_configs.m_name, id);
        return true;
      }
      //���߳�poll����. �����Ϣ�ص�����
      bool call(MessagePtr m) const{
        MYASSERT(m_calls);
        MYASSERT(m_calls->m_messageCall);
        m_calls->m_messageCall(m_configs.m_name, m);
        return true;
      }
      bool isCompress() const { return m_configs.m_compress; }

      //��һ���µĻỰ��Ϣ���ӳɹ�.  ��listenThread���������̵߳���
      bool threadConnect();

      bool setAllow(const std::string& allow){
        if (!isServerPeer()){
          return false;
        }
        m_configs.m_allow = allow;
        return true;
      }

      void freeTcp(){
        if(m_tcp) {
          podFree(m_tcp);
          m_tcp = nullptr;
          LOGDEBUG("free tcp:", m_configs.m_name);
        }
      }
    private:
      NetConfig m_configs;          //������Ϣ
      NetServiceData* m_service;    //������������ָ��
      uv_tcp_t* m_tcp;              //���������Ķ˿ڰ�(server����)
      NetCallBackPtr m_calls;       //�ص�����
    };

    typedef std::shared_ptr<NetSignalData> SignalPointer;
    typedef Utility::ObjPtrMap<SessionId, NetSession>  SessionMap;
    typedef Utility::ObjPtrMap<NetName, NetSignalData> NetSigMap;
    typedef std::set<SignalPointer> NetSigSet;

    class NetServiceData{
    private:
      NetServiceData(const NetServiceData&) = delete;
      NetServiceData& operator = (const NetServiceData&) = delete;
    public:
      enum ServiceState {
        _SERVICE_INIT_ = 0,
        _SERVICE_RUN_ = 1,
        _SERVICE_STOP_ = 2,
      };
      enum  {
        _DEFAULT_BUFFER_SIZE = 65535,
      };
      

      explicit NetServiceData(unsigned int c)
        : m_state(_SERVICE_INIT_)
        , m_currentId(INVALID_SESSION_ID)
        , m_workThreadCount(c) {
        m_loop = podMalloc<uv_loop_t>();
        m_workThreadCount = c > 0 ? c : 1;
        m_sessions.setOptional(INVALID_SESSION_ID);
        m_nets.setOptional("");
        uv_mutex_init(&m_addMutex);
      }
      virtual ~NetServiceData() {
        m_threads.clear();
        m_sessions.clear();
        m_nets.clear();
        podFree(m_loop);
        uv_mutex_destroy(&m_addMutex);
      }
      //����һ���µĻỰ,���ҷ���һ��NetThread(��д)�߳�
      SessionPtr addNewSession(const NetConfig& config, const FunMakeBlock& fun) {
        ThreadPtr t;
        size_t value = 0;
        for (auto& tt : m_threads){
          if (!t ||  value < tt->busy()){t = tt;value = tt->busy();}
        }
        ++m_currentId;
        return  SessionPtr(new NetSession(t, m_currentId, _DEFAULT_BUFFER_SIZE, config, fun));
      }
      //poll��Ϣ�����߳�
      bool poll() {
        //MYASSERT(m_state == NetServiceData::_SERVICE_RUN_);
        std::list<MessagePtr> msglist;
        std::list<SessionPtr> connectionDisConnSet;
        std::list<SessionPtr> connectionConnSet;
        for(auto& t : m_threads) {
          t->pollThread(msglist, connectionConnSet, connectionDisConnSet);
        }
        for(auto& s : connectionConnSet) {
          auto obj = m_nets.getData(s->config().m_name);
          MYASSERT(obj);
          if (obj->sessionCheck(s)){
            m_sessions.addData(s->id(), s);
            obj->connect(s->id());
          }else{
            realKick(s);
          }
        }

        for(auto& m : msglist) {
          auto s = m_sessions.getData(m->session());
          if(s) {
            auto obj = m_nets.getData(s->config().m_name);
            MYASSERT(obj);
            obj->call(m);
          }
        }

        for (auto& s : connectionDisConnSet){
          auto obj = m_nets.getData(s->config().m_name);
          MYASSERT(obj);
          obj->close(s->id());
          m_sessions.eraseData(s->id());
          if(s->isClient()) { m_nets.eraseData(s->config().m_name); }
        }
        
        return true;
      }

      void stop(unsigned int ms){
        if (_SERVICE_STOP_ == m_state){return;}
        m_state = _SERVICE_STOP_;
        int r = uv_async_send(&m_asyncStop);
        uvError("uv_async_send:", r);


        std::chrono::steady_clock::time_point clockBegin = std::chrono::steady_clock::now();
        auto tick = [&]()-> unsigned int {
          auto du = std::chrono::steady_clock::now() - clockBegin;
          return std::chrono::duration_cast<std::chrono::milliseconds>(du).count();
        };
        do{
          poll();
        } while(tick() < ms || check());

        r = uv_thread_join(&m_mainThread);
        uvError("uv_thread_join:", r);
        for(auto& t : m_threads) { t->stop(); }
      }

      bool isRun() const { return m_state == _SERVICE_RUN_; }

      bool setAllow(const NetName& name, const std::string& allow){
        auto obj = m_nets.getData(name);
        if (obj){
          return obj->setAllow(allow);
        }
        return false;
      }
      bool check() const{
        for (auto&t :m_threads){
          if (t->check()){
            return true;
          }
        }
        return false;
      }

      //�˿������߳�
      void listenThread() {
        NetSigMap& _map = m_nets;
        int r = uv_loop_init(m_loop);
        uvError("uv_loop_init:", r);
        m_asyncStop.data = this;
        m_asyncNew.data = this;
        for(unsigned int i = 0; i < m_workThreadCount; ++i) {
          ThreadPtr ptr(new NetThread());
          m_threads.push_back(ptr);
        }

        // begin init listen server
        for(const auto& pair :_map.constRefMap()) {
          const auto& c = pair.second;
          if (c->isServerPeer()){c->listen(m_loop);}
          if (c->isClientPeer()){c->client();}
        }
        //call thread run
        for(auto& t : m_threads) {t->createThread();}
        //run loop
        r = uv_async_init(m_loop, &m_asyncStop, callStopSercive);
        uvError("uv_async_init:", r);
        r = uv_async_init(m_loop, &m_asyncNew, callAddNet);
        uvError("uv_async_init:", r);
        r = uv_run(m_loop, UV_RUN_DEFAULT);
        uvError("uv_run:", r);
        r = uv_loop_close(m_loop);
        uvError("uv_loop_close:", r);
        LOGDEBUG("exit net listen thread");
      }
      //�رչ����߳� ��listenThread���������̵߳���
      void stopThreads() {
        uv_close((uv_handle_t*)&m_asyncStop, callCloseSync);
        uv_close((uv_handle_t*)&m_asyncNew, callCloseSync);
        for(auto& v : m_nets.constRefMap()) { v.second->stop(); }
        int r = uv_loop_alive(m_loop);
        while( r == 0){
          r = uv_loop_alive(m_loop);
          uv_stop(m_loop);
          LOGDEBUG("set exit listen thread");
          break;
        }
      }
      //�����������ģ��
      bool start(){
        LOGDEBUG("uv:", uv_version_string());
        int r = uv_thread_create(&m_mainThread, callService, this);
        uvError("uv_thread_create:", r);
        m_state = NetServiceData::_SERVICE_RUN_;
        return true;
      }
      //ɾ��һ���ͻ������͵��������
      bool removeClient(const std::string& name){
        auto n = m_nets.getData(name);
        if (n && n->isClientPeer()){
          for (auto& pair : m_sessions.constRefMap()){
            if (pair.second->config().m_name == name){
              return kick( pair.first);
            }
          }
        }
        return false;
      }

      
      //���߳�����
      bool kick(SessionId id){
        auto s = m_sessions.getData(id);
        return realKick(s);
      }
      //����һ���������
      bool add(const NetConfig& config, NetCallBackPtr calls) {
        if(config.m_name.empty()) { return false; }
        if(m_nets.hasData(config.m_name)) { return false; }
        if(_SERVICE_STOP_ == m_state) { return false; }
        
        SignalPointer ptr(new NetSignalData(config, this, std::move(calls)));
        m_nets.addData(config.m_name, ptr);

        if(_SERVICE_RUN_ == m_state) {
          NetGuardLock locker(&m_addMutex);
          m_addSet.insert(ptr);
          int r = uv_async_send(&m_asyncNew);
          uvError("uv_async_send:", r);
        }
        return true;
      }
      //������Ϣ
      bool send(const MessagePtr& msg){
        auto s = m_sessions.getData(msg->session());
        if(s) {
          auto t = s->thread();
          if(!t) { MYASSERT(false);  return false; }
          msg->lock(s->config().m_compress);
          t->pushWrite(msg);
          return true;
        }
        return false;
      }
      //������Ϣ
      bool send(const NetName& name, const MessagePtr& msg) {
        auto p = m_nets.getData(name);
        if(!p) { return false; }
        msg->lock(p->isCompress());
        for(auto& pair : m_sessions.constRefMap()) {
          auto s = pair.second;
          if(s && s->config().m_name == name) {
            MessagePtr ptr(msg->clone(s->id()));
            send(ptr);
          }
        }
        return true;
      }
      //֪ͨ���������������  ��listenThread���������̵߳���
      void addNetSync(){
        NetSigSet _set;
        {
          NetGuardLock locker(&m_addMutex);
          _set = m_addSet;
          m_addSet.clear();
        }
        for(auto c : _set) {
          if(c->isServerPeer()) {
            c->listen(m_loop);
          } 
          if(c->isClientPeer()) {
            c->client();
          }
        }
      }
    private:
      bool realKick(SessionPtr s) {
        if(s) { return s->kicked(); }
        return false;
      }
    protected:
      uv_async_t  m_asyncStop;                    //ֹͣ�������
      uv_async_t  m_asyncNew;                     //�¼����������
      uv_thread_t m_mainThread;                   //���������߳�
      uv_loop_t*  m_loop = nullptr;               //m_mainThread ��loop
      std::list<ThreadPtr> m_threads;             //�����̳߳�
      SessionMap m_sessions;
      NetSigMap m_nets;
      NetSigSet m_addSet;
      ServiceState m_state;                       //����״̬
      SessionId m_currentId = INVALID_SESSION_ID; //��һ��session id 
      unsigned int m_workThreadCount;             //�����շ��߳�����
      uv_mutex_t m_addMutex;
    };


    bool NetSignalData::threadConnect() {
      SessionPtr s = m_service->addNewSession(m_configs, m_calls->m_makeBlockCall);
      if(s) {
        return s->accept((uv_stream_t*)m_tcp);
      }else{
        MYASSERT(false);
        return false;
      }
    }
    bool NetSignalData::client(){
      SessionPtr s = m_service->addNewSession(m_configs, m_calls->m_makeBlockCall);
      auto t = s->thread();
      if(!t) { MYASSERT(false); return false; }
      return t->addNewClient(s);
    }
    void callService(void* p) {
      NetServiceData* ptr = static_cast<NetServiceData*>(p);
      if(ptr) {
        ptr->listenThread();
      }
    }
    void callStopSercive(uv_async_t* handle) {
      NetServiceData* ptr = static_cast<NetServiceData*>(handle->data);
      if(ptr) {
        ptr->stopThreads();
      }
    }
    void callAddNet(uv_async_t* handle) { 
      NetServiceData* p = static_cast<NetServiceData*>(handle->data);
      if (p){
        p->addNetSync();
      }
    }

    void callSessionConnect(uv_stream_t* tcp, int status) {
      if(status == -1) { return; }
      NetSignalData* ptr = static_cast<NetSignalData*>(tcp->data);
      if(ptr) { ptr->threadConnect(); }
    }
    void callTcpServiceStop(uv_handle_t* handle) {
      NetSignalData* ptr = static_cast<NetSignalData*>(handle->data);
      if(ptr) {
        ptr->freeTcp();
      }
    }
    NetService::NetService(unsigned int t)
      :m_serviceData(new NetServiceData(t)) {
    }
    NetService::~NetService(){
      stop(0);
      m_serviceData.reset();
    }

    bool NetService::start() {
      if(!m_serviceData) { return false; }
      return m_serviceData->start();
    }

    void NetService::stop(unsigned int ms) {
      m_serviceData->stop(ms);
    }
    bool NetService::remove(const NetName& name) {
      return m_serviceData->removeClient(name);
    }
    bool NetService::add(const NetConfig& config, NetCallBackPtr calls) {
      return m_serviceData->add(config, std::move(calls));
    }
    bool NetService::poll() {
      return m_serviceData->poll();
    }
    bool NetService::send(const MessagePtr& msg) {
      return m_serviceData->send(msg);
    }
    bool NetService::send(const NetName& name, const MessagePtr& msg) {
      return m_serviceData->send(name, msg);
    }
    bool NetService::kick(const SessionId& id) {
      return m_serviceData->kick(id);
    }
    bool NetService::isRun() const {
      return m_serviceData->isRun();
    }
    bool NetService::setAllow(const NetName& name, const std::string& allow) {
      return m_serviceData->setAllow(name, allow);
    }
  }
}