/********************************************************************
	Filename: 	NetSession.cpp
	Description:
	Version:  1.0
	Created:  31:3:2016   11:11
	
	Compiler: gcc vc
	Author:   wufan, love19862003@163.com
	Organization: lezhuogame
*********************************************************************/
#include "net/NetSession.h"
#include "net/NetThread.h"
#include "utility/Compress.h"
namespace ShareSpace {
  namespace NetSpace {
  
    static void callWrite(uv_write_t* req, int status) {
      SessionPtr s = static_cast<NetSession*>(req->data)->shared_from_this();
      if (s){
        s->writeResult(status);
      }
    }
    static void callConnect(uv_connect_t* req, int status){
      SessionPtr s = static_cast<NetSession*>(req->data)->shared_from_this();
      if (s){
        s->connetResult(status);
      }
    }
    static void callAlloc(uv_handle_t* handle, size_t len, uv_buf_t* buff) {
      SessionPtr s = static_cast<NetSession*>(handle->data)->shared_from_this();
      if(s) {
        s->allocReadBuffer(len, buff);
      }else{
        MYASSERT(false);
      }
    }
    static  void callRead(uv_stream_t* stream, ssize_t nread, const uv_buf_t* buf) {
      SessionPtr s = static_cast<NetSession*>(stream->data)->shared_from_this();
      if (s){
        s->readResult(stream, nread, buf);
      }
    }
    static void callShutDown(uv_shutdown_t* req, int /*status*/) {
      SessionPtr s = static_cast<NetSession*>(req->data)->shared_from_this();
      if(s) {
        s->close();
      }
    }
    static void callClose(uv_handle_t* handle){
      SessionPtr s = (static_cast<NetSession*>(handle->data))->shared_from_this();
      if(s) { s->closeResult(); }
    }
    NetSession::NetSession(ThreadPtr t,
                        SessionId id,
                        size_t len,
                        const NetConfig& config,
                        const FunMakeBlock& fun)
                        : m_thread(t)
                        , m_sessionId(id)
                        , m_bufferSend(new NetBuffer(len))
                        , m_bufferRecv(new NetBuffer(len))
                        , m_waiteMessage(nullptr)
                        , m_state(_session_init_)
                        , m_config(config)
                        , m_inSend(false)
                        , m_reconn(config.m_autoReconnect)
                        ,m_makeBlockFun(fun){
      m_tcp = podMalloc<uv_tcp_t>();
      m_connect = podMalloc<uv_connect_t>();
      m_write = podMalloc<uv_write_t>();
      m_shutDown = podMalloc<uv_shutdown_t>();
      m_tcp->data = this;
      m_connect->data = this;
      m_write->data = this;
      m_shutDown->data = this;
    }
    NetSession::~NetSession() {
      podFree(m_tcp);
      podFree(m_connect);
      podFree(m_write);
      podFree(m_shutDown);
      m_thread.reset();
      m_bufferSend.reset();
      m_bufferRecv.reset();
      m_waiteMessage.reset();
    }

    ThreadPtr  NetSession::thread() {
      if(!m_thread.expired()) {
        return m_thread.lock();
      } else {
        return nullptr;
      }
    }

    void NetSession::allocReadBuffer(size_t len, uv_buf_t* buff) {
      size_t ll = m_bufferRecv->maxLength() - m_bufferRecv->length();
      size_t l = std::min<size_t>(len, ll);
      uv_buf_t b = uv_buf_init(m_bufferRecv->writeData(), l);
      *buff = b;
    }
    MessagePtr NetSession::readMessage(){
      if(!m_waiteMessage) { m_waiteMessage = m_makeBlockFun(m_sessionId); }
      if(m_waiteMessage) {
        m_waiteMessage->recv(m_bufferRecv);
        if(m_waiteMessage->done()) {
          auto p = m_waiteMessage;
          MYASSERT(!p->error(), "crc32 check is error");
          m_waiteMessage = nullptr;
          return p;
        }
      }
      return nullptr;
    }
    bool NetSession::readResult(uv_stream_t* stream, ssize_t nread, const uv_buf_t* buf) {
      if(nread >= 0 && buf && buf->base && buf->len > 0) {
        std::list<MessagePtr> list;
        size_t size = 0;
        m_bufferRecv->writeData(nread);
        auto t = thread();
        if(!t) { MYASSERT(false);  return false; }
        while(m_bufferRecv->hasWrite()) {
          auto m = readMessage();
          if(m) {
            list.push_back(m);
            m_recvTotalCount++;
            m_recvTotalLen += m->length();
            size += m->length();
          } else { break; }
        }
        t->recvMsgList(list, size);
        return true;
      }
      int r = uv_shutdown(m_shutDown, stream, callShutDown);
      uvError("uv_shutdown:", r);
      return false;
    }
    void NetSession::read(){
      int r = uv_read_start((uv_stream_t*)m_tcp, callAlloc, callRead);
      uvError("begin read " + m_config.m_name + " session:" + std::to_string(m_sessionId) + " r:", r);
      return;
    }
    void NetSession::connetResult(int status){
      if(!isClient()) { return; }
      auto t = thread();
      if(!t) { MYASSERT(false); return; }
      if (0 == status){
        m_state = _session_connect_;
        t->activeSession(shared_from_this());
        read();
      }else{
        LOGINFO("connect ", m_config.m_name, " failed");
        if(m_reconn) { clientConnect(); } else { close(false); }
      }
    }

    void NetSession::close( bool call){
      uv_close((uv_handle_t*)m_tcp, call ? callClose : nullptr);
    }
    void NetSession::closeResult(){
      auto t = thread();
      if(!t) { MYASSERT(false);  return; }
      m_state = _session_close_;
      if (isClient() && m_reconn ){
        // server close.  so real need reconnect ??
        // clientConnect();
        m_waiteMessage.reset();
        m_bufferRecv->reset(true);
        m_bufferSend->reset(true);
        MYASSERT(false);
        //return 
      }
      t->closeSession(shared_from_this());
    }
    void NetSession::initConnect(){
      auto t = thread();
      if(!t) { return ; }
      MYASSERT(m_config.m_serviceType == _CLIENT_FLAG_);
      int r = uv_tcp_init(t->loop(), m_tcp);
      uvError("uv_tcp_init:", r);
      clientConnect();
    }
    bool NetSession::clientConnect() {
      if (m_reconn){
        struct sockaddr_in addr;
        int r = uv_ip4_addr(m_config.m_address.c_str(), m_config.m_port, &addr);
        uvError("uv_ip4_addr:", r)
        r = uv_tcp_connect(m_connect, m_tcp, (const struct sockaddr*)&addr, callConnect);
        if(r!= 0) { LOGDEBUG("connect ", m_config.m_name, " error:", uv_err_name(r)); clientConnect(); }
      }
      return true;
    }
    bool NetSession::accept(uv_stream_t* server){
      auto t = thread();
      if(!t) { MYASSERT(false); return false; }
      int r = uv_tcp_init(t->loop(), m_tcp);
      uvError("uv_tcp_init:", r);
      bool result = true;
      if(0 == uv_accept(server, (uv_stream_t*)m_tcp)) {
        struct sockaddr_in addr;
        int len = sizeof(sockaddr_in);
        r = uv_tcp_getpeername(m_tcp, (sockaddr*)&addr, &len);
        uvError("uv_tcp_getpeername:", r);
        m_ip = inet_ntoa(addr.sin_addr);
        m_state = _session_connect_;
        result = true;
      } else {
        close(false);
        result = false;
      }
      //����uv_accept��֤m_tcp���ӳɹ����ټ��뵽�߳̿�ʼ��д�¼� 
      t->addSession(shared_from_this());
      return result;
    }


    bool NetSession::fillWrite(MessagePtr m){
      if (m_inSend || m_bufferSend->isFull()){return false;}
      m->readBuffer(*m_bufferSend);
      return true;
    }
    void NetSession::write(){
      uv_buf_t buf;
      buf.base = m_bufferSend->data();
      buf.len = m_bufferSend->length();
      int r = uv_write(m_write, (uv_stream_t*)m_tcp, &buf, 1, callWrite);
      uvError("uv_write:", r);
      m_inSend = true;
    }

    void NetSession::writeResult(int status) {
      if(status > 0) {
        int r = uv_shutdown(m_shutDown, (uv_stream_t*)m_tcp, callShutDown);
        uvError("uv_shutdown:", r);
        return;
      }
      m_sendTotalLen += m_bufferSend->length();
      m_bufferSend->reset();
      m_inSend = false;
      auto t = thread();
      if(t) { t->realSend(); } else { MYASSERT(false); }
    }
    void NetSession::unReconn() {
      m_reconn = false;  
    }
    bool NetSession::kicked(){
      m_reconn = false;
      auto t = thread();
      if(t) { return t->kick(shared_from_this()); }
      return false;
    }



    //////////////////////////////////////////////////////////////////////////
  }
}