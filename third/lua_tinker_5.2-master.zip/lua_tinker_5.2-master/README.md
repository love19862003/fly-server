lua_tinker_5.2
==============

lua_tinker for lua 5.2  
![](https://github.com/zfengzhen/lua_tinker_5.2/blob/master/lua_tinker_note.jpg)
