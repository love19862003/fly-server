print("cpp_int = "..cpp_int)


lua_int = 200
