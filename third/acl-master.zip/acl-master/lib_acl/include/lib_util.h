#ifndef	__LIB_UTIL_INCLUDE_H__
#define	__LIB_UTIL_INCLUDE_H__

#ifdef	__cplusplus
extern "C" {
#endif

#include "lib_acl.h"

#ifdef	__cplusplus
}
#endif

#endif

