#ifndef	ACL_MYDB_INCLUDE_H
#define	ACL_MYDB_INCLUDE_H

# ifdef	__cplusplus
extern "C" {
# endif

#include "acl_dbpool.h"
#include "acl_dberr.h"
#include "acl_dbsql.h"
#include "acl_mdb.h"

# ifdef	__cplusplus
}
# endif

#endif

