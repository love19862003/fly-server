#!/bin/sh

./master_dispatch alone "./dispatch2.sock;1082" master_dispatch2.cf
