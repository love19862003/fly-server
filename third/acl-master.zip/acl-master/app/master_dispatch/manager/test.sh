#!/bin/sh

./dispatch_manager alone dispatch_manager.cf
