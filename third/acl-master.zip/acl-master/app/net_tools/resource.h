//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by net_tools.rc
//
#define IDR_241                         1
#define IDR_MENU_ICON                   4
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_NET_TOOLS_DIALOG            102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_HTML_OPTIONONCLOSE          106
#define IDR_MAINFRAME                   128
#define IDD_OPTION                      131
#define IDR_RT_MANIFEST1                139
#define IDI_ICON1                       142
#define IDI_ICON_MIN                    142
#define IDD_DIALOG1                     143
#define IDD_DIALOG_QUIT                 143
#define IDC_PING                        1000
#define IDC_NSLOOKUP                    1001
#define IDC_IP_FILE_PATH                1002
#define IDC_LOAD_IP                     1003
#define IDC_DOMAIN_FILE                 1004
#define IDC_LOAD_DOMAIN                 1005
#define IDC_NPKT                        1006
#define IDC_DELAY                       1007
#define IDC_TIMEOUT                     1008
#define IDC_BUTTON4                     1009
#define IDC_OPEN_DOS                    1009
#define IDC_NPKT_SIZE                   1010
#define IDC_PKT_SIZE                    1010
#define IDC_DNS_IP                      1011
#define IDC_DNS_PORT                    1012
#define IDC_LOOKUP_TIMEOUT              1013
#define IDC_UPLOAD                      1014
#define IDC_TESTALL                     1015
#define IDC_OPTION                      1016
#define IDC_SMTP_ADDR                   1017
#define IDC_SMTP_PORT                   1018
#define IDC_POP3_ADDR                   1019
#define IDC_POP3_PORT                   1020
#define IDC_SEND_MAIL                   1020
#define IDC_USER_ACCOUNT                1021
#define IDC_RECV_MAIL                   1021
#define IDC_USER_PASSWD                 1022
#define IDC_RECIPIENTS                  1023
#define IDC_LOAD_FILE                   1023
#define IDC_FILE                        1025
#define IDC_RECV_LIMIT                  1026
#define IDC_RECV_ALL                    1027
#define IDC_RECV_ALL2                   1028
#define IDC_RECV_SAVE                   1028
#define IDC_STATIC_SMTP_ADDR            1030
#define IDC_STATIC_PASS                 1031
#define IDC_CHECK_SAVE                  1031
#define IDC_STATIC_POP3_ADDR            1032
#define IDC_QUIT_YES                    1032
#define IDC_STATIC_USER                 1033
#define IDC_QUIT_NO                     1033
#define IDC_STATIC_RECIPIENTS           1034
#define ID_OPEN_MAIN                    32773
#define ID_QUIT                         32774

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        144
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1034
#define _APS_NEXT_SYMED_VALUE           107
#endif
#endif
