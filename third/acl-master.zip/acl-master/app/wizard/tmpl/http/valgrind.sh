#!/bin/sh

valgrind --tool=memcheck --leak-check=yes -v ./$<PROGRAM> alone $<PROGRAM>.cf
