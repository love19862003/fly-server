#ifndef	__HTML_TEMPLATE_INCLUDE_H__
#define	__HTML_TEMPLATE_INCLUDE_H__

/* in html_template.c */
extern char HTTP_REPLY_DNS_ERR[];
extern char HTTP_REPLY_TIMEOUT[];
extern char HTTP_REPLY_ERROR[];
extern char HTTP_REQUEST_INVALID[];
extern char HTTP_REQUEST_LOOP[];
extern char HTTP_CONNECT_ERROR[];
extern char HTTP_CONNECT_TIMEOUT[];
extern char HTTP_REQUEST_DENY[];
extern char HTTP_REQUEST_NOFOUND[];
extern char HTTP_INTERNAL_ERROR[];

#endif
