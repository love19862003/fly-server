﻿using System;
using System.Xml.Serialization;

namespace Ice.Configure.Global
{
    /// <summary>
    /// 配置文件的Root节点。
    /// </summary>
    [XmlRoot("Configure")]
    public class Configure
    {
        public Configure()
        {
            Global = new Global();
            Global.Network = new Network();
            Global.RpcNetwork = new RpcNetwork();
        }
        /// <summary>
        /// 服务器全局配置
        /// </summary>
        [XmlElement("Global")]
        public virtual Global Global { get; set; }

        /// <summary>
        /// Site列表。
        /// </summary>
        [XmlArray("Sites"), XmlArrayItem("Site")]
        public virtual Site[] Sites { get; set; }

        /// <summary>
        /// 根据指定的服务器名称获得指定的服务器全局配置信息（名称大小写不敏感）。
        /// </summary>
        /// <param name="serverDNName">指定的服务器名称。siteid.realmid.servername </param>  todo 这个需要改成全局名称
        /// <returns>指定的服务器全局配置信息</returns>
        public Server FindServer(String serverDNName)
        {
            Server result = null;
            Int32 siteId;
            Int32 realmId;
            String serverName;
            Int32 or = SplitServerDNName(serverDNName, out siteId, out realmId, out serverName);
            if (or != 0)
                return null;
            result = FindServer(siteId, realmId, serverName);
            return result;
        }

        /// <summary>
        /// 根据全名制服务器名找相关Server配置，并返回相关节点信息
        /// </summary>
        /// <param name="serverDNName"></param>
        /// <param name="siteId"></param>
        /// <param name="realmId"></param>
        /// <param name="serverId"></param>
        /// <returns></returns>
        public Server FindServer(String serverDNName, out Int32 siteId, out Int32 realmId, out Int32 serverId)
        {
            serverId = 0;
            String serverName;
            Server result = null;
            Int32 or = SplitServerDNName(serverDNName, out siteId, out realmId, out serverName);
            if (or != 0)
                return null;
            result = FindServer(siteId, realmId, serverName);
            if (result != null)
                serverId = result.Id;
            return result;
        }

        /// <summary>
        /// 找相关Server配置
        /// </summary>
        /// <param name="siteId"></param>
        /// <param name="realmId"></param>
        /// <param name="serverName"></param>
        /// <returns>找到为相关Server对象，否则为null</returns>
        public Server FindServer(Int32 siteId, Int32 realmId, String serverName)
        {
            Server result = null;
            foreach (Site site in Sites)
            {
                if (siteId != site.Id)
                    continue;
                foreach (Realm realm in site.Realms)
                {
                    if (realmId != realm.Id)
                        continue;
                    foreach (Server server in realm.Servers)
                    {
                        if (server.Name.ToLower() != serverName.ToLower())
                            continue;
                        result = server;
                        break;
                    }
                    break;
                }
                break;
            }
            return result;
        }

        /// <summary>
        /// 找相关Server配置
        /// </summary>
        /// <param name="siteId"></param>
        /// <param name="realmId"></param>
        /// <param name="serverId"></param>
        /// <returns>找到为相关Server对象，否则为null</returns>
        public Server FindServer(Int32 siteId, Int32 realmId, Int32 serverId)
        {
            Server result = null;
            foreach (Site site in Sites)
            {
                if (siteId != site.Id)
                    continue;
                foreach (Realm realm in site.Realms)
                {
                    if (realmId != realm.Id)
                        continue;
                    foreach (Server server in realm.Servers)
                    {
                        if (server.Id != serverId)
                            continue;
                        result = server;
                        break;
                    }
                    break;
                }
                break;
            }
            return result;
        }

        /// <summary>
        /// 将全名制服务器名分割成相关服务器配置信息字段
        /// </summary>
        /// <param name="serverDNName">全名制服务器名</param>
        /// <param name="siteId"></param>
        /// <param name="realmId"></param>
        /// <param name="serverName"></param>
        /// <returns>操作成功：0，操作失败：1</returns>
        private Int32 SplitServerDNName(String serverDNName, out Int32 siteId, out Int32 realmId, out String serverName)
        {
            siteId = 0;
            realmId = 0;
            serverName = null;
            if (serverDNName == null || serverDNName.Length < 5)
                return -4;
            String[] szInfo = serverDNName.Split('.');
            if (szInfo.Length != 3)
                return -1;
            siteId = Int32.Parse(szInfo[0]);
            if (siteId < 1)
                return -2;
            realmId = Int32.Parse(szInfo[1]);
            if (realmId < 1)
                return -3;
            serverName = szInfo[2];
            return 0;
        }
    }

    public class Global
    {
        /// <summary>
        /// Network参数配置
        /// </summary>
        [XmlElement("Network")]
        public Network Network;

        /// <summary>
        /// RpcNetwork参数配置
        /// </summary>
        [XmlElement("RpcNetwork")]
        public RpcNetwork RpcNetwork;
    }

    public class Network
    {
        public Network()
        {
            InputBufferLen = 2048;
            OutputBufferLen = 8192;
            SocketInputBufferLen = 8192;
            SocketInputBufferLen = 8192;
        }
        /// <summary>
        /// 接收缓冲区大小
        /// </summary>
        [XmlAttribute("InputBufferLen")]
        public Int32 InputBufferLen;

        /// <summary>
        /// 发送缓冲区大小
        /// </summary>
        [XmlAttribute("OutputBufferLen")]
        public Int32 OutputBufferLen;

        /// <summary>
        /// 对应的socket连接接受缓冲区大小
        /// </summary>
        [XmlAttribute("SocketInputBufferLen")]
        public Int32 SocketInputBufferLen;

        /// <summary>
        /// 对应的socket连接发送缓冲区大小
        /// </summary>
        [XmlAttribute("SocketOutputBufferLen")]
        public Int32 SocketOutputBufferLen;
    }

    public class RpcNetwork
    {
        public RpcNetwork()
        {
            InputBufferLen = 65536;
            OutputBufferLen = 65536;
            SocketInputBufferLen = 65536;
            SocketOutputBufferLen = 65536;
        }
        [XmlAttribute("InputBufferLen")]
        public Int32 InputBufferLen;

        [XmlAttribute("OutputBufferLen")]
        public Int32 OutputBufferLen;

        [XmlAttribute("SocketInputBufferLen")]
        public Int32 SocketInputBufferLen;

        [XmlAttribute("SocketOutputBufferLen")]
        public Int32 SocketOutputBufferLen;
    }

    /// <summary>
    /// 配置文件的Site节点。
    /// </summary>
    public class Site
    {
        /// <summary>
        /// 当前Site的ID。
        /// </summary>
        [XmlAttribute("Id")]
        public Int32 Id { get; set; }

        /// <summary>
        /// 当前Site的显示名称。
        /// </summary>
        [XmlAttribute("DisplayName")]
        public String DisplayName { get; set; }

        /// <summary>
        /// 当前Site的Realm列表
        /// </summary>
        [XmlArray("Realms"), XmlArrayItem("Realm")]
        public Realm[] Realms { get; set; }
    }

    /// <summary>
    /// 配置文件的Realm节点。
    /// </summary>
    public class Realm
    {
        /// <summary>
        /// 当前Realm的ID。
        /// </summary>
        [XmlAttribute("Id")]
        public Int32 Id { get; set; }

        /// <summary>
        /// 当前Realm的显示名称。
        /// </summary>
        [XmlAttribute("DisplayName")]
        public String DisplayName { get; set; }

        /// <summary>
        /// 当前Realm的数据目录。
        /// </summary>
        [XmlAttribute("DataPath")]
        public String DataPath { get; set; }

        /// <summary>
        /// 当前Realm的脚本目录。
        /// </summary>
        [XmlAttribute("ScriptPath")]
        public String ScriptPath { get; set; }

        /// <summary>
        /// 当前Realm的Realm列表
        /// </summary>
        [XmlArray("Servers"), XmlArrayItem("Server")]
        public Server[] Servers { get; set; }
    }

    /// <summary>
    /// 配置文件的Server节点。
    /// </summary>
    public class Server
    {
        /// <summary>
        /// 当前Server的ID。
        /// </summary>
        [XmlAttribute("Id")]
        public Int32 Id { get; set; }

        /// <summary>
        /// 当前Server的名称,必须Realm中唯一。
        /// </summary>
        [XmlAttribute("Name")]
        public String Name { get; set; }

        /// <summary>
        /// 当前Server的显示名称。
        /// </summary>
        [XmlAttribute("DisplayName")]
        public String DisplayName { get; set; }

        /// <summary>
        /// 当前Server的类型名称。
        /// </summary>
        [XmlAttribute("TypeName")]
        public String TypeName { get; set; }

        /// <summary>
        /// 当前Server需要开启Rpc所绑定的地址。
        /// </summary>
        [XmlAttribute("RpcIP")]
        public String RpcIP { get; set; }

        /// <summary>
        /// 当前Server需要开启Rpc所绑定的端口。
        /// </summary>
        [XmlAttribute("RpcPort")]
        public Int32 RpcPort { get; set; }

        /// <summary>
        /// 绑定的端口服务IP。
        /// </summary>
        [XmlAttribute("EndPointIP")]
        public String EndPortIP { get; set; }

        /// <summary>
        /// 绑定的端口服务端口。
        /// </summary>
        [XmlAttribute("EndPointPort")]
        public Int32 EndPortPort { get; set; }

        /// <summary>
        /// 是否开启端口。
        /// </summary>
        [XmlAttribute("EndPointEnable")]
        public bool IsEndPointEnable { get; set; }

        /// <summary>
        /// 是否开启RPC服务。
        /// </summary>
        [XmlAttribute("RPCEnable")]
        public bool IsRPCEnable { get; set; }

        /// <summary>
        /// 当前Server特定的配置文件路径。
        /// </summary>
        [XmlAttribute("Conf")]
        public String ConfFile { get; set; }
    }
}
