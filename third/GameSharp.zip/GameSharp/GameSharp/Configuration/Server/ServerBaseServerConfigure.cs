﻿using System;
using System.Xml.Serialization;

/// <summary>
/// 定义所有服务器配置文件的共通属性。
/// </summary>
namespace Lava.Configure.Server
{
    /// <summary>
    /// 配置文件根节点。
    /// </summary>
    [Serializable]
    [XmlRoot("Configure")]
    public class ConfigureRoot
    {
        [XmlElement("PlayerContext")]
        public PlayerContext PlayerContext { get; set; }

        /// <summary>
        /// 日志配置信息。
        /// </summary>
        [XmlElement("Log")]
        public Log Log { get; set; }
        

    }

    [Serializable]
    public class PlayerContext
    {
        /// <summary>
        /// 服务器玩家现场个数上限
        /// </summary>
        [XmlAttribute("CountMax")]
        public Int32 CountMax { get; set; }
    }

    /// <summary>
    /// 日志配置节点。
    /// </summary>
    [Serializable]
    public class Log
    {
        /// <summary>
        /// 是否开启文件日志。
        /// </summary>
        [XmlAttribute("FileEnable")]
        public bool IsFileEnable { get; set; }

        /// <summary>
        /// 是否开启控制台日志。
        /// </summary>
        [XmlAttribute("ConsoleEnable")]
        public bool IsConsoleEnable { get; set; }

        /// <summary>
        /// 文件日志配置信息。
        /// </summary>
        [XmlElement("File")]
        public LogFile File { get; set; }

        /// <summary>
        /// 控制台日志配置信息。
        /// </summary>
        [XmlElement("Console")]
        public LogConsole Console { get; set; }
    }
    
    /// <summary>
    /// 文件日志配置节点。
    /// </summary>
    [Serializable]
    public class LogFile
    {
        /// <summary>
        /// 日志文件路径名。
        /// </summary>
        [XmlAttribute("Path")]
        public String Path { get; set; }

        /// <summary>
        /// 日志输出格式。
        /// </summary>
        [XmlAttribute("Layout")]
        public String Layout { get; set; }

        /// <summary>
        /// 日志输出的最小等级。
        /// </summary>
        [XmlAttribute("MinLevel")]
        public String MinLevel { get; set; }

        /// <summary>
        /// 日志是输出的最大等级。
        /// </summary>
        [XmlAttribute("MaxLevel")]
        public String MaxLevel { get; set; }
    }

    /// <summary>
    /// 控制台日志配置节点。
    /// </summary>
    [Serializable]
    public class LogConsole
    {
        /// <summary>
        /// 日志输出格式。
        /// </summary>
        [XmlAttribute("Layout")]
        public String Layout { get; set; }

        /// <summary>
        /// 日志输出的最小等级。
        /// </summary>
        [XmlAttribute("MinLevel")]
        public String MinLevel { get; set; }

        /// <summary>
        /// 日志是输出的最大等级。
        /// </summary>
        [XmlAttribute("MaxLevel")]
        public String MaxLevel { get; set; }
    }
}
