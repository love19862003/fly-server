﻿using Lava.SampleGame.RpcProtocol;
using System;
using GolbalConfig = Lava.SampleGame.Configure.SampleGlobalConfigure;
using ServerConfig = Lava.SampleGame.Configure.SampleCenterServerConfigure;

namespace Lava.SampleGame.CenterServer
{
    class Program
    {
        static void Main(string[] args)
        {
            if (2 != args.Length)
            {
                Console.WriteLine("CenterServer para is error !");
                Console.ReadLine();
                return;
            }
            CenterServer cs = new CenterServer();
            if (!CenterServer.Instance.Initialize<GolbalConfig, ServerConfig>(args[0], args[1], new SampleGameRpcProtocolDictionary()))
            {
                Console.WriteLine("CenterServer initial fail !");
                Console.ReadLine();
                return;
            }

            //centerServer.Working();

            String str=Console.ReadLine();
            while (str.CompareTo("Q")!=0)
            {
                str = Console.ReadLine();
            }
            CenterServer.Instance.Uninitialize();
        }
    }
}
