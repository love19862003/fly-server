﻿using System;
using Lava.Protocol;
using Lava.ServerFramework.CenterServerBase;
using Lava.SampleGame.Configure;
using System.Linq;

namespace Lava.SampleGame.CenterServer
{
    /// <summary>
    /// 中心服务器管理类
    /// </summary>
    class CenterServer : CenterServerBase
    {
        /// <summary>
        /// 构造函数
        /// </summary>
        public CenterServer()
        {
            needFriendServer = false;
        }

        /// <summary>
        /// 初始化
        /// </summary>
        /// <returns>成功：true</returns>
        public override Boolean Initialize<TGlobalConfigClass, TServerConfigClass>(String globalConfPath, String serverDNName, IProtoDictionary rpcProtoDictionary)
        {
            Boolean result = false;

            // 检查配置对象类型是否是SampleCenterServerConfigure子类
            if (typeof(TServerConfigClass) != typeof(SampleCenterServerConfigure) &&
                !typeof(TServerConfigClass).IsSubclassOf(typeof(SampleCenterServerConfigure)))
            {
                Console.WriteLine("CenterServer::Initialization checked TServerConfigClass = {0} failed",
                    typeof(TServerConfigClass).ToString());
                return false;
            }
            // 检查配置对象类型是否是SampleGlobalConfig子类
            if (typeof(TGlobalConfigClass) != typeof(SampleGlobalConfigure) &&
                !typeof(TGlobalConfigClass).IsSubclassOf(typeof(SampleGlobalConfigure)))
            {
                Console.WriteLine("CenterServer::Initialization checked TGlobalConfigClass = {0} failed",
                    typeof(TGlobalConfigClass).ToString());
                return false;
            }

            // 基类初始化
            Console.WriteLine("CenterServer::Initialization call base.Initialize");
            result = base.Initialize<TGlobalConfigClass, TServerConfigClass>(globalConfPath, serverDNName, rpcProtoDictionary);
            if (!result)
            {
                Console.WriteLine("CenterServer::Initialization base.Initialize failed");
                return false;
            }

            //获取特定的全局配置
            GlobalConfig = base.GlobalConfig as SampleGlobalConfigure;
            if (GlobalConfig == null)
            {
                Log.ErrorFormat("CenterServer::Initialization get GlobalConfig failed");
                return false;
            }
            //设置好友服务器配置项
            needFriendServer = GlobalConfig.ServerRequirement.FriendServerRequire.IsRequire;
            return true;
        }

        /// <summary>
        /// 应用层判断是否注册是有效的
        /// </summary>
        /// <param name="ctx">玩家现场，可能为空，说明是导致现场创建的注册行为</param>
        /// <param name="serverId">服务器Id</param>
        /// <returns>有效：true</returns>
        protected override bool IsPlayerCtxRegValid(CenterPlayerContext ctx, Int32 serverId)
        {
            //FS必须在GS注册完成的前提下才能注册
            if (needFriendServer)
            {
                if (ctx == null || (ctx._registerDict.Where((a) => { return a.Value._serverType == "GS"; })).Count() == 0)
                {
                    //好友服务器判断
                    if (GetLocalServerConfigByServerId(serverId).TypeName == "FS")
                    {
                        return false;
                    }
                }
            }
            return base.IsPlayerCtxRegValid(ctx, serverId);
        }

        protected override void OnPlayerContextUnregisted(CenterPlayerContext ctx, CenterPlayerCtxRegItem item, Int32 reason)
        {
            base.OnPlayerContextUnregisted(ctx, item, reason);

            // if serverid == gameserver, StartPlayerShutdown
            //如果GameServer注销了现场，那么就关闭玩家现场，这只是一个简单的处理示例。
            if (GetLocalServerConfigByServerId(item._serverId).TypeName == "GS")
            {
                StartPlayerShutdown(ctx, reason);
            }
        }

        /// <summary>
        /// 静态实例
        /// </summary>
        public static new CenterServer Instance
        { get { return (CenterServer)(CenterServerBase.Instance); } }

        /// <summary>
        /// 获取全局特定配置数据
        /// </summary>
        public new Lava.SampleGame.Configure.SampleGlobalConfigure GlobalConfig { get; private set; }

        /// <summary>
        /// 是否需要好友服务器
        /// </summary>
        public Boolean needFriendServer { get; private set; }
    }
}
