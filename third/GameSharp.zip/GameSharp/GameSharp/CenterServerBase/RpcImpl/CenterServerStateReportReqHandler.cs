﻿using Lava.RpcSharp;
using Lava.ServerFramework.RpcProtocol;

namespace Lava.ServerFramework.CenterServerBase
{
    /// <summary>
    /// Gamer Server 到 Center Server 人数动态更新请求处理类
    /// </summary>
    public class CenterServerStateReportReqHandler : ICenterServerStateReportReqHandler
    {
        /// <summary>
        /// Rpc包处理接口
        /// </summary>
        /// <param name="rpcData">Rpc包</param>
		/// <param name="context">context</param>
		public void OnMessage(CenterServerStateReportReq rpcData, RpcHandlerContext context)
        {
            CenterServerBase.Instance.OnServerStateReportReq(rpcData.Info, rpcData.NeedAck);
        }
    }
}
