﻿using Ice.RpcSharp;
using Ice.ServerFrameWork.CenterServerBase.Rpc.Process;
using Ice.ServerFrameWork.RpcProtocol;

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ice.ServerFrameWork.CenterServerBase.Rpc
{
    /// <summary>
    /// Center Server RpcProcessCall字典
    /// </summary>
    class CenterRpcProcessCallDictionary : IRpcProcessCallProvider
    {
        /// <summary>
        /// 通过Rpc包获取相关处理服务
        /// </summary>
        /// <param name="rpcDataType">Rpc包类型</param>
        /// <returns>相关Rpc处理</returns>
		public Type GetRpcHandlerFromType(Type rpcDataType)
        {
            Type result;
            _typeHandlerMap.TryGetValue(rpcDataType, out result);
            return result;
        }

        /// <summary>
        /// 单间Default
        /// </summary>
        public static CenterRpcProcessCallDictionary Default { get; private set; }

        /// <summary>
        /// 生成字典
        /// </summary>
        static CenterRpcProcessCallDictionary()
        {
            Default = new CenterRpcProcessCallDictionary();
			
			Func<Type, Boolean> predicater = t => t.GetCustomAttributes(
				typeof(ProtocolHandlerInterfaceAttribute), inherit: false).Length > 0;
            foreach (Type interface_ in Utils.TypeSpider.FindTypesInSolution(predicater))
			{
				Type lastDescendant = null;
				ProtocolHandlerInterfaceAttribute attr = (ProtocolHandlerInterfaceAttribute)interface_.GetCustomAttributes(
					typeof(ProtocolHandlerInterfaceAttribute), inherit: false)[0];
				Type messageType = attr.MessageType;

				foreach (Type subclass in Utils.TypeSpider.FindTypesInSolution(t => t.GetInterfaces().Contains(interface_)))
				{
					if (lastDescendant == null || subclass.IsSubclassOf(lastDescendant))
					    lastDescendant = subclass;
					else if (/* NOT */! lastDescendant.IsSubclassOf(subclass))
						throw new Exception(string.Format("More than one seperated descendant of handler interface {0}.", interface_));
				}

				if (lastDescendant != interface_)
					Default._typeHandlerMap.TryAdd(messageType, lastDescendant);
			}
        }

        /// <summary>
        /// 私有构造函数
        /// </summary>
        private CenterRpcProcessCallDictionary() { }

        /// <summary>
        /// 字典容器
        /// </summary>
        private ConcurrentDictionary<Type, Type> _typeHandlerMap = new ConcurrentDictionary<Type, Type>();
    }
}
