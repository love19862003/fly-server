﻿using Lava.RpcSharp;
using Lava.ServerFramework.RpcProtocol;

namespace Lava.ServerFramework.CenterServerBase
{
    /// <summary>
    /// Gamer Server 到 Center Server 玩家取消注册请求处理类
    /// </summary>
    public class CenterPlayerContextUnregisterReqProcess : ICenterPlayerContextUnregisterReqHandler
    {
        /// <summary>
        /// Rpc包处理接口
        /// </summary>
        /// <param name="rpcData">Rpc包</param>
		public void OnMessage(CenterPlayerContextUnregisterReq rpcData, RpcHandlerContext context)
        {
            CenterServerBase.Instance.OnPlayerContextUnregisterReq(rpcData.SessionID, rpcData.ServerID, rpcData.Reason);
        }
    }
}
