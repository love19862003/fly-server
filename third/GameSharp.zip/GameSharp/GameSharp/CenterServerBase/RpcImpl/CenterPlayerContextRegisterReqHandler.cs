﻿using Lava.RpcSharp;
using Lava.ServerFramework.RpcProtocol;

namespace Lava.ServerFramework.CenterServerBase
{
    /// <summary>
    /// Gamer Server 到 Center Server 玩家注册请求处理类
    /// </summary>
    public class CenterPlayerContextRegisterReqProcess : ICenterPlayerContextRegisterReqHandler
    {
        /// <summary>
        /// Rpc包处理接口
        /// </summary>
        /// <param name="rpcData">Rpc包</param>
		public void OnMessage(CenterPlayerContextRegisterReq rpcData, RpcHandlerContext context)
        {
            CenterServerBase.Instance.OnPlayerContextRegisterReq(rpcData.SessionId, rpcData.GameUserID, rpcData.ServerID);
            return;
        }
    }
}
