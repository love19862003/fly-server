﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using Lava.Protocol;
using Lava.ServerFramework.RpcProtocol;
using Lava.ServerBase;
using Lava.ServerFramework.Configure;
using Lava.RpcSharp;
using System.Runtime.CompilerServices;

namespace Lava.ServerFramework.CenterServerBase
{
    /// <summary>
    /// 服务器状态列表条目
    /// </summary>
    public class CenterServerStateListItem
    {
        public Int32 _serverID = 0;
        public UInt16 _contextCount = 0;
        public UInt16 _contextCountMax = 0;
        public DateTime _lastReportTime = DateTime.MinValue;
    }

    /// <summary>
    /// 玩家现场和服务器关联关系的注册条目
    /// </summary>
    public class CenterPlayerCtxRegItem
    {
        public Int32 _serverId = 0;
        public String _serverType = null;

        /// <summary>
        /// 0:idle,1:registed,2:unregisting,3:unregisted
        /// </summary>
        public Int32 _regState = 0;
    }

    /// <summary>
    /// centerserver上的用户现场
    /// </summary>
    public class CenterPlayerContext
    {
        public UInt64 _sessionId = 0;
        public String _gameUserId = null;
        public Boolean _waitForShutdown = false;
        public DateTime _startShutdownTime = DateTime.MaxValue;
        public Int32 _shutdownReason = 0;
        public Dictionary<Int32, CenterPlayerCtxRegItem> _registerDict = new Dictionary<Int32, CenterPlayerCtxRegItem>();
    }

    /// <summary>
    /// 中心服务器管理类
    /// </summary>
    public class CenterServerBase : Lava.ServerBase.ServerBase
    {
        /// <summary>
        /// 构造函数
        /// </summary>
        public CenterServerBase()
        {
        }

        /// <summary>
        /// 初始化
        /// </summary>
        /// <returns>成功：true</returns>
        public virtual Boolean Initialize<TGlobalConfigClass, TServerConfigClass>(String globalConfPath, String serverDNName, IProtoDictionary rpcProtoDictionary)
            where TGlobalConfigClass : Lava.ServerFramework.Configure.ServerFrameworkGlobalConfigureRoot, new()
            where TServerConfigClass : Lava.Configure.Server.ConfigureRoot, new() 
        {
            Boolean result = false;

            Console.WriteLine("CenterServerBase::Initialization");            

            // 基类初始化
            Console.WriteLine("CenterServerBase::Initialization call base.Initialize");
            result = base.Initialize<TGlobalConfigClass, TServerConfigClass>(globalConfPath, serverDNName, null, null, rpcProtoDictionary);

            // 失败退出
            if (!result)
            {
                if (Log == null)
                    Console.WriteLine("CenterServerBase::Initialization base.Initialize failed");
                else
                    Log.ErrorFormat("CenterServerBase::Initialization base.Initialize failed");
                return false;
            }

            //获取FriendServer的Rpc句柄
            FriendServerRpcHandle = GetRpcServerByLocalServerName("Friend");
            if (FriendServerRpcHandle == null)
            {
                Log.ErrorFormat("CenterServerBase::Initialization fail to GetRpcServerByServerName for FriendServer");
                return false;
            }

            // 启动服务器状态报告扫描timer
            Log.InfoFormat("CenterServerBase::Initialization TimerManager.SetLoopTimer for serverStateReportTimer");
            _serverStateReportTimerID = TimerManager.SetLoopTimer(
                ServerFrameworkConstDefine.CENTERSERVER_SERVERSTATEREPORT_TIMER_PERIOD, ServerStateReportTimerCallBack);
            // 启动玩家现场状态扫描timer
            Log.InfoFormat("CenterServerBase::Initialization TimeManager.SetLoopTimer for CenterPlayerCtxStateTimer");
            _playerCtxStateTimerID = TimerManager.SetLoopTimer(
                ServerFrameworkConstDefine.CENTERSERVER_PLAYERSTATEREPORT_TIMER_PERIOD, PlayerCtxStateReportTimerCallBack);

            if (_serverStateReportTimerID == Int64.MinValue)
            {
                Log.ErrorFormat("CenterServerBase::Initialization TimerManager.SetLoopTimer failed");
                return false;
            }

            Log.InfoFormat("CenterServerBase::Initialization end of being called successful");
            return true;
        }

        /// <summary>
        /// 停止服务器
        /// </summary>
        public override void Uninitialize()
        {
            Log.InfoFormat("CenterServerBase::Uninitialize");
            // 停止服务器状态扫描timer
            TimerManager.UnsetLoopTimer(_serverStateReportTimerID);

            // 基类的关服
            base.Uninitialize();

            Log.InfoFormat("CenterServerBase::Uninitialize end of being called");
        }

        /// <summary>
        /// [ThreadSafe]其他服务器向centerserver报告自己的状态
        /// </summary>
        /// <param name="info"></param>
        /// <param name="needAck"></param>
        public virtual void OnServerStateReportReq(ServerStateBasicInfo info, Boolean needAck)
        {
            if (info == null)
            {
                Log.ErrorFormat("CenterServerBase::OnServerStateReportReq, but info is null");
                return;
            }

            CenterServerStateListItem item;

            //Log.DebugFormat("CenterServerBase::OnServerStateReportReq, info(ServerID={0} ContextCount={1} ContextCountMax={2}) needAck={3}", 
            //    info.ServerID.ToString(), info.ContextCount.ToString(), info.ContextCountMax.ToString(), needAck.ToString());
            // 找到对应得服务器状态数据
            bool bRet = _mapServerId2State.TryGetValue(info.ServerID, out item);
            if (!bRet || item == null)
            {
                item = AllocateServerStateListItem(info.ServerID);
                if (item == null)
                {
                    Log.ErrorFormat("CenterServerBase::OnServerStateReportReq AllocateServerStateListItem failed");
                    return;
                }
                _mapServerId2State.TryAdd(info.ServerID, item);
            }


            // 更新服务器状态数据
            lock (item)
            {
                item._serverID = info.ServerID;
                item._contextCount = (UInt16)info.ContextCount;
                item._contextCountMax = (UInt16)info.ContextCountMax;
                item._lastReportTime = DateTime.Now;
            }

            // 如果需要ack则发送服务器列表数据
            if (needAck)
            {
                SendServerStateReportAck(info.ServerID);
            }
        }

        /// <summary>
        /// 玩家登录注册请求处理
        /// </summary>
        /// <param name="sessionid"></param>
        /// <param name="gameUserId"></param>
        /// <param name="serverId"></param>
        public virtual void OnPlayerContextRegisterReq(UInt64 sessionid, String gameUserId, Int32 serverId)
        {
            if (gameUserId == null || gameUserId.Length < 1)
            {
                Log.ErrorFormat("CenterServerBase::OnPlayerContextRegisterReq, but gameUserId is checked failed");
                return;
            }
            CenterPlayerContext ctx;
            Lava.Configure.Global.Server serverConf = GetLocalServerConfigByServerId(serverId);

            Log.DebugFormat("CenterServerBase::OnPlayerContextRegisterReq, sessionid={0} gameUserId={1} serverId={2}",
                sessionid.ToString(), gameUserId, serverId.ToString());
            if (serverConf == null)
            {
                Log.ErrorFormat("CenterServerBase::OnPlayerContextRegisterReq serverId={0} couldn't find!", serverId.ToString());
                // 发送SendPlayerContextRegisterAck
                SendPlayerContextRegisterAck(sessionid, gameUserId, serverId, ServerFrameworkConstDefine.CENTERSERVER_PLAYERCTX_REGISTERACK_RESULT_UNKNOWN);
                return;
            }

            // 首先查询sid对应的ctx是否已经存在
            if (!_mapSid2PlayerCtx.TryGetValue(sessionid, out ctx))
            {
                // 如果不存在说明首次注册，需要检查重复登录问题
                // 查询gameUserId是否已经由对应的ctx
                if (_mapGameUserId2PlayerCtx.TryGetValue(gameUserId, out ctx))
                {
                    if (ctx._sessionId != sessionid)
                    {
                        Log.ErrorFormat("CenterServerBase::OnPlayerContextRegisterReq gameUserIdPlayerCtx({0}) check sessionid failed!", gameUserId);
                        // 通知应用层登录冲突发生
                        OnLoginConflict(sessionid, serverId, ctx);
                        SendPlayerContextRegisterAck(sessionid, gameUserId, serverId, ServerFrameworkConstDefine.CENTERSERVER_PLAYERCTX_REGISTERACK_RESULT_LOGINCONFLICT);
                        return;
                    }
                    else // 如果出现sid相同的情况，基本是不可能的，放弃当前请求
                    { 
                        Log.ErrorFormat("CenterServerBase::OnPlayerContextRegisterReq only had gameUserIdPlayerCtx({0})!", gameUserId);
                        SendPlayerContextRegisterAck(sessionid, gameUserId, serverId, ServerFrameworkConstDefine.CENTERSERVER_PLAYERCTX_REGISTERACK_RESULT_UNKNOWN);
                        return;
                    }
                }

                // 如果不存在需要创建，这个时候留给应用层一个机会决定是否可以创建，例如有些服务器的注册是需要以其他服务器注册为前提的
                // 让应用层判断是否注册是有效的
                if (!IsPlayerCtxRegValid(null, serverId))
                {
                    Log.ErrorFormat("CenterServerBase::OnPlayerContextRegisterReq ctx({0}) IsPlayerCtxRegValid failed!", gameUserId);
                    SendPlayerContextRegisterAck(sessionid, gameUserId, serverId, ServerFrameworkConstDefine.CENTERSERVER_PLAYERCTX_REGISTERACK_RESULT_REGINVALID);
                    // 当有非法的时候通知应用层
                    OnPlayerContextRegisterInvalid(serverId, ctx);
                    return;
                }

                // 不存在则创建新的
                ctx = AllocatePlayerContext();
                ctx._sessionId = sessionid;
                ctx._gameUserId = gameUserId;

                // 将新的ctx加入到注册表，失败的可能非常小
                if (!_mapGameUserId2PlayerCtx.TryAdd(gameUserId, ctx) || !_mapSid2PlayerCtx.TryAdd(sessionid, ctx)) // todo:wangqi
                {
                    Log.ErrorFormat("CenterServerBase::OnPlayerContextRegisterReq gameUserId={0} _mapgameUserId2PlayerCtx tryadd or _mapSid2PlayerCtx tryadd failed!", gameUserId);
                    SendPlayerContextRegisterAck(sessionid, gameUserId, serverId, ServerFrameworkConstDefine.CENTERSERVER_PLAYERCTX_REGISTERACK_RESULT_UNKNOWN);
                    return;
                }
            }
            else
            {
                // 当现场已经处于关闭中的时候不能处理注册
                if (ctx._waitForShutdown)
                {
                    Log.ErrorFormat("CenterServerBase::OnPlayerContextRegisterReq ctx({0}) is waiting for shutdown!", gameUserId);
                    SendPlayerContextRegisterAck(sessionid, gameUserId, serverId, ServerFrameworkConstDefine.CENTERSERVER_PLAYERCTX_REGISTERACK_RESULT_UNKNOWN);
                    return;
                }
            }

            lock (ctx)
            {
                CenterPlayerCtxRegItem item;

                // 如果相同的serverid已经存在注册现场了
                if (ctx._registerDict.ContainsKey(serverId))
                {
                    item = ctx._registerDict[serverId];
                    // 这种情况不应该发生reg
                    if (item._regState == 1 || item._regState == 2)
                    {
                        Log.ErrorFormat("CenterServerBase::OnPlayerContextRegisterReq ctx({0}) res state is {1}!", gameUserId, item._regState.ToString());
                        SendPlayerContextRegisterAck(sessionid, gameUserId, serverId, ServerFrameworkConstDefine.CENTERSERVER_PLAYERCTX_REGISTERACK_RESULT_REGCONFLICT);
                        // 当有冲突的时候通知应用层
                        OnPlayerContextRegisterConflict(serverId, ctx);
                        return;
                    }
                }
                else 
                {
                    // 让应用层判断是否注册是有效的
                    if (!IsPlayerCtxRegValid(ctx, serverId))
                    {
                        Log.ErrorFormat("CenterServerBase::OnPlayerContextRegisterReq ctx({0}) IsPlayerCtxRegValid failed!", gameUserId);
                        SendPlayerContextRegisterAck(sessionid, gameUserId, serverId, ServerFrameworkConstDefine.CENTERSERVER_PLAYERCTX_REGISTERACK_RESULT_REGINVALID);
                        // 当有非法的时候通知应用层
                        OnPlayerContextRegisterInvalid(serverId, ctx);
                        return;
                    }

                    item = AllocatePlayerCtxRegItem();
                    item._serverId = serverId;
                    item._serverType = serverConf.TypeName;
                    ctx._registerDict.Add(serverId, item);
                }

                // 设置当前状态为已经注册
                item._regState = 1;

                // 返回注册成功
                SendPlayerContextRegisterAck(sessionid, gameUserId, serverId, 0);
            }
        }

        /// <summary>
        /// [ThreadSafe]其他服务器向center通知注销现场关联
        /// </summary>
        /// <param name="sessionid"></param>
        /// <param name="serverId"></param>
        /// <param name="reason"></param>
        public virtual void OnPlayerContextUnregisterReq(UInt64 sessionid, Int32 serverId, Int32 reason)
        {
            CenterPlayerContext ctx;
            CenterPlayerCtxRegItem item;

            Log.DebugFormat("CenterServerBase::OnPlayerContextUnregisterReq, sessionid={0} serverId={1} reason={2}",
                sessionid.ToString(), serverId.ToString(), reason.ToString());

            if (!_mapSid2PlayerCtx.TryGetValue(sessionid, out ctx))
            {
                Log.ErrorFormat("CenterServerBase::OnPlayerContextUnregisterReq get ctx({0}) failed!", sessionid.ToString());
                return;
            }

            lock (ctx)
            {
                if (!ctx._registerDict.TryGetValue(serverId, out item))
                {
                    Log.ErrorFormat("CenterServerBase::OnPlayerContextUnregisterReq get item({0}) failed!", serverId.ToString());
                    return;
                }

                // 只有在1:registed,2:unregisting才能进行unreg
                if (item._regState != 1 && item._regState != 2)
                {
                    Log.ErrorFormat("CenterServerBase::OnPlayerContextUnregisterReq get item state is {0}!", item._regState.ToString());
                    return;
                }

                // 从注册关系中移除
                ctx._registerDict.Remove(serverId);

                // 设置当前item状态为unreged
                item._regState = 3;

                // 当现场中没有任何注册关系存在的时候释放现场
                if (ctx._registerDict.Count == 0)
                {
                    CenterPlayerContext tempCtx;
                    _mapSid2PlayerCtx.TryRemove(ctx._sessionId, out tempCtx);
                    _mapGameUserId2PlayerCtx.TryRemove(ctx._gameUserId, out tempCtx);
                    Log.InfoFormat("CenterServerBase::OnPlayerContextUnregisterReq player({0})'s ctx is remove!", ctx._gameUserId);
                }
            }            

            OnPlayerContextUnregisted(ctx, item, reason);
        }
        
        /// <summary>
        /// [ThreadSafe]当服务器和玩家现场的注册关系已经注销,这里需要根据reason和当前注销的服务器类型，
        /// 决定当前这次注销行为是否会导致center发起对其他服务器现场关联的主动关闭（GameCenterPlayerContextCloseReq）
        /// </summary>
        /// <param name="ctx"></param>
        /// <param name="item"></param> 
        /// <param name="reason"></param>
        protected virtual void OnPlayerContextUnregisted(CenterPlayerContext ctx, CenterPlayerCtxRegItem item, Int32 reason)
        {
            lock(ctx)
            {
                if(ctx._waitForShutdown)
                {
                    OnProceedPlayerShutdown(ctx, item._serverId, reason);
                    return;
                }
            }

            // 当由于关键错误导致的注销
            if (reason == ServerFrameworkConstDefine.CENTERSERVER_PLAYERCTX_UNREGISTER_REASON_CRITFAIL)
            { 
                StartPlayerShutdown(ctx, ServerFrameworkConstDefine.CENTERSERVER_PLAYERCTX_CLOSE_REASON_CRITFAIL);
            }

            // 子类的重载需要决定, 什么服务器的注销会引发StartPlayerShutdown
        }

        /// <summary>
        /// [ThreadSafe]当本次玩家现场注册发生了login冲突,即相同的gameUserId已经存在一个对应现场，
        /// 在本函数中决定对老的现场是否需要进行处理
        /// </summary>
        /// <param name="newSessionid"></param>
        /// <param name="newServerId"></param>
        /// <param name="oldCtx"></param>
        protected virtual void OnLoginConflict(UInt64 newSessionid, Int32 newServerId, CenterPlayerContext oldCtx)
        {
            StartPlayerShutdown(oldCtx);
        }

        /// <summary>
        /// [ThreadSafe]当本次玩家现场注册发生了服务器关联冲突
        /// [LockReenter]该函数可能处于嵌套的CenterPlayerContext锁环境被调用
        /// </summary>
        /// <param name="newServerId"></param>
        /// <param name="ctx"></param>
        protected virtual void OnPlayerContextRegisterConflict(Int32 newServerId, CenterPlayerContext ctx)
        { 
        }

        /// <summary>
        /// [ThreadSafe]当本次玩家现场注册是非法的，应用层判断非法
        /// [LockReenter]该函数可能处于嵌套的CenterPlayerContext锁环境被调用
        /// </summary>
        /// <param name="newServerId"></param>
        /// <param name="ctx">可能为空</param>
        protected virtual void OnPlayerContextRegisterInvalid(Int32 newServerId, CenterPlayerContext ctx)
        { 
        }

        /// <summary>
        /// [ThreadSafe]开始玩家现场的shutdown操作，依照一定顺序向其他服务器发送GameCenterPlayerContextCloseReq
        /// </summary>
        /// <param name="ctx">玩家现场</param>
        /// <param name="reason"></param>
        protected virtual void StartPlayerShutdown(CenterPlayerContext ctx,
            Int32 reason = ServerFrameworkConstDefine.CENTERSERVER_PLAYERCTX_CLOSE_REASON_NORMAL)
        {
            lock (ctx)
            {
                if (!ctx._waitForShutdown)
                {
                    ctx._waitForShutdown = true;
                    // 记录shutdown时间
                    ctx._startShutdownTime = DateTime.Now;
                }

                if (ctx._shutdownReason != ServerFrameworkConstDefine.CENTERSERVER_PLAYERCTX_CLOSE_REASON_CRITFAIL &&
                    ctx._shutdownReason != ServerFrameworkConstDefine.CENTERSERVER_PLAYERCTX_CLOSE_REASON_RESHUTDOWN)
                {
                    ctx._shutdownReason = reason;
                }

                foreach (KeyValuePair<Int32, CenterPlayerCtxRegItem> pair in ctx._registerDict)
                {
                    if (pair.Value._regState == 1 || pair.Value._regState == 2)
	                {
                        // 这里直接close了所有的服务器现场关联
                        // 但是在实际游戏中可能服务器类型比较多，关闭会有顺序，例如 GW->Map->DBApp
                        SendGameCenterPlayerContextCloseReq(ctx, pair.Value, ctx._shutdownReason);
	                }                    
                }
            }

            /*当发生严重错误 或者 已经执行过StartPlayerShutdown的玩家现场却一直没有等到对应服务器返回的UnregisterReq，则都
              可以认为对应的那个服务器挂掉了。这时直接清理掉CenterServer上的玩家现场信息*/
            if (reason == ServerFrameworkConstDefine.CENTERSERVER_PLAYERCTX_CLOSE_REASON_CRITFAIL ||
                reason == ServerFrameworkConstDefine.CENTERSERVER_PLAYERCTX_CLOSE_REASON_RESHUTDOWN)
            {
                CenterPlayerContext tempCtx;
                _mapSid2PlayerCtx.TryRemove(ctx._sessionId, out tempCtx);
                _mapGameUserId2PlayerCtx.TryRemove(ctx._gameUserId, out tempCtx);
                Log.InfoFormat("CenterServerBase::StartPlayerShutdown player({0})'s ctx is remove! for reason={1}", ctx._gameUserId, reason);
            }
        }

        /// <summary>
        /// [ThreadSafe]继续玩家现场的shutdown操作
        /// [LockReenter]该函数可能处于嵌套的CenterPlayerContext锁环境被调用
        /// </summary>
        /// <param name="ctx">玩家现场</param>
        /// <param name="newUnregServerId"></param>
        protected virtual void OnProceedPlayerShutdown(CenterPlayerContext ctx, Int32 newUnregServerId, Int32 reason)
        {
            // 在实际游戏中，这个地方检测按照当前的服务器关联现场关闭顺序，下面应该关闭什么服务器上的玩家现场（GameCenterPlayerContextCloseReq）
        }

        /// <summary>
        /// [ThreadSafe]组装需要广播的服务器列表数据，需要广播哪些，由应用层决定
        /// </summary>
        /// <param name="serverId">服务器Id</param>
        protected virtual void SendServerStateReportAck(Int32 serverId)
        {
            // 获取RpcServer接口
            IRpcServer rpcServer = GetRpcServerByLocalServerId(serverId);
            if (rpcServer == null)
            {
                Log.ErrorFormat("CenterServerBasse::SendServerStateReportAck, serverId={0}, but rpcServer is null", 
                    serverId.ToString());
                return;
            }
                

            // 组包
            CenterServerStateReportAck serversStateAck = new CenterServerStateReportAck();
            foreach (KeyValuePair<Int32, CenterServerStateListItem> pair in _mapServerId2State)
            {
                if (pair.Value._serverID <= 0 || pair.Value._contextCountMax <= 0)
                    continue;
                ServerStateBasicInfo serverState = new ServerStateBasicInfo();
                serverState.ServerID = pair.Value._serverID;
                serverState.ContextCount = pair.Value._contextCount;
                serverState.ContextCountMax = pair.Value._contextCountMax;
                serversStateAck.Infos.Add(serverState);
            }
            // 如果数据包有数据再发
            if (serversStateAck.Infos.Count > 0)
            {
                Int32 sendCount = rpcServer.SendPackage(serversStateAck);
                if (sendCount != 0)
                {
                    Log.ErrorFormat("CenterServerBasse::SendServerStateReportAck SendPackage={0}", sendCount.ToString());
                }
            }
        }

        /// <summary>
        /// 发送玩家注册反馈信息
        /// </summary>
        /// <param name="sessionid">玩家游戏服务器唯一编号</param>
        /// <param name="gameUserId">玩家帐号</param>
        /// <param name="serverId">服务器Id</param>
        /// <param name="result">发送成功：true</param>
        /// <returns></returns>
        protected virtual bool SendPlayerContextRegisterAck(UInt64 sessionid, String gameUserId, Int32 serverId, Int32 result)
        {
            // 获取RpcServer接口
            IRpcServer rpcServer = GetRpcServerByLocalServerId(serverId);
            if (rpcServer == null)
            {
                Log.ErrorFormat("CenterServerBasse::SendPlayerContextRegisterAck, serverId={0}, but rpcServer is null",
                    serverId.ToString());
                return false;
            }

            // 组包
            CenterPlayerContextRegisterAck centerPlayercontextRegisterAck = new CenterPlayerContextRegisterAck();
            centerPlayercontextRegisterAck.GameUserId = gameUserId;
            centerPlayercontextRegisterAck.SessionId = sessionid;
            centerPlayercontextRegisterAck.Result = result;

            // 发送
            Int32 sendCount = rpcServer.SendPackage(centerPlayercontextRegisterAck);

            if (sendCount == 0)
                return true;
            else
            {
                Log.ErrorFormat("CenterServerBasse::SendPlayerContextRegisterAck SendPackage={0}", sendCount.ToString());
                return false;
            }
        }

        /// <summary>
        /// 发送玩家现场关闭请求
        /// </summary>
        /// <param name="sessionid">玩家游戏服务器唯一编号</param>
        /// <param name="serverId">服务器Id</param>
        /// <param name="reason">关闭理由</param>
        /// <returns>发送成功：true</returns>
        protected virtual bool SendGameCenterPlayerContextCloseReq(CenterPlayerContext ctx, CenterPlayerCtxRegItem item, Int32 reason)
        {
            // 获取RpcServer接口
            IRpcServer rpcServer = GetRpcServerByLocalServerId(item._serverId);
            if (rpcServer == null)
                return false;

            // 组包
            GameCenterPlayerContextCloseReq gameCenterPlayerContextCloseReq = new GameCenterPlayerContextCloseReq();
            gameCenterPlayerContextCloseReq.SessionId = ctx._sessionId;
            gameCenterPlayerContextCloseReq.Reason = reason;

            // 发送
            Int32 sendCount = rpcServer.SendPackage(gameCenterPlayerContextCloseReq);

            if (sendCount == 0)
                return true;
            else
            {
                Log.ErrorFormat("CenterServerBasse::SendGameCenterPlayerContextCloseReq SendPackage={0}", sendCount.ToString());
                return false;
            }
        }

        /// <summary>
        /// 生成服务器状态条目对象允许被继承
        /// </summary>
        /// <param name="serverId">服务器Id</param>
        /// <returns>生成的服务器状态条目对象</returns>
        protected virtual CenterServerStateListItem AllocateServerStateListItem(Int32 serverId)
        {
            return new CenterServerStateListItem();
        }

        /// <summary>
        /// 生成玩家现场对象
        /// </summary>
        /// <returns>生成的玩家现场对象</returns>
        protected virtual CenterPlayerContext AllocatePlayerContext()
        {
            return new CenterPlayerContext();
        }

        /// <summary>
        /// 生成玩家服务器关联条目对象
        /// </summary>
        /// <returns>生成的玩家服务器关联条目对象</returns>
        protected virtual CenterPlayerCtxRegItem AllocatePlayerCtxRegItem()
        {
            return new CenterPlayerCtxRegItem();
        }

        /// <summary>
        /// 让应用层判断是否注册是有效的
        /// </summary>
        /// <param name="ctx">玩家现场，可能为空，说明是导致现场创建的注册行为</param>
        /// <param name="serverId">服务器Id</param>
        /// <returns>有效：true</returns>
        protected virtual bool IsPlayerCtxRegValid(CenterPlayerContext ctx, Int32 serverId)
        {
            // 默认行为当ctx为空需要创建的时候允许创建，应用层在这里需要检查是否能够允许为指定serverid创建ctx
            if (ctx == null)
            {
                return true;
            }

            // 在ctx已经存在情况下的默认注册行为检查
            Lava.Configure.Global.Server serverConfig = GetLocalServerConfigByServerId(serverId);
            if (serverConfig != null)
            {
                foreach (KeyValuePair<Int32, CenterPlayerCtxRegItem> pair in ctx._registerDict)
                {
                    // 默认的情况当有同类型server注册的时候认为是存在冲突
                    if (serverConfig.TypeName == pair.Value._serverType)
                    {
                        return false;
                    }
                }
            }
            return true;
        }

        /// <summary>
        /// 服务器timer callback 每5秒一次
        /// </summary>
        /// <param name="int32Data">参数</param>
        /// <param name="int64Data">参数</param>
        /// <param name="obj">参数</param>
        protected virtual void ServerStateReportTimerCallBack(Int32 int32Data, Int64 int64Data, Object obj)
        {
            // 计算超时时间
            DateTime expireTime = DateTime.Now - TimeSpan.FromMilliseconds(ServerFrameworkConstDefine.CENTERSERVER_SERVERSTATEREPORT_TIMEOUT);
            // 过滤出所有超期的服务器
            var expiredItems = _mapServerId2State.Where(o => o.Value._lastReportTime < expireTime);
            foreach (var pair in expiredItems)
            {
                // 将超期的item移除并通知应用层
                CenterServerStateListItem serverInfo;
                bool bRet = _mapServerId2State.TryRemove(pair.Key, out serverInfo);
                if (bRet)
                {
                    // 通知应用层
                    OnServerReportTimeOut(serverInfo);
                }                
            }
        }

        /// <summary>
        /// 服务器PlayerCtx timer callback，主要用来监视调用StartPlayerShutdown后接收到其他服务器unregisterReq的超时
        /// </summary>
        /// <param name="int32Data"></param>
        /// <param name="int64Data"></param>
        /// <param name="obj"></param>
        protected virtual void PlayerCtxStateReportTimerCallBack(Int32 int32Data, Int64 int64Data, Object obj)
        {
            foreach (var playerCtx in _mapSid2PlayerCtx)
            {
                //满足这个条件，说明玩家现场已经在关闭了，正在等待对应服务器返回unregisterReq
                if (playerCtx.Value._waitForShutdown == true)
                {
                    //这时判断有没有超过等待时间
                    DateTime shutdownTime = playerCtx.Value._startShutdownTime;
                    if (shutdownTime != DateTime.MinValue && (DateTime.Now - shutdownTime).TotalMilliseconds >
                        ServerFrameworkConstDefine.CENTERSERVER_PLAYERSHUTDOWN_TIMEOUT)
                    {
                        //超时了，直接通过StartPlayerShutdown清理现场
                        StartPlayerShutdown(playerCtx.Value, ServerFrameworkConstDefine.CENTERSERVER_PLAYERCTX_CLOSE_REASON_RESHUTDOWN);
                    }
                }
            }
        }

        /// <summary>
        /// 提供给子类来实现，当timer发现serverreport超时的时候调用
        /// </summary>
        /// <param name="item">服务器状态对象</param>
        protected virtual void OnServerReportTimeOut(CenterServerStateListItem item)
        {
            if (item == null)
            {
                Log.ErrorFormat("CenterServerBase::OnServerReportTimeOut, but item is null");
            }
            Log.DebugFormat("CenterServerBase::OnServerReportTimeOut, item(_serverID={0} _contextCount={1} _contextCountMax={2})", 
                item._serverID.ToString(), item._contextCount.ToString(), item._contextCountMax.ToString());
            foreach (var playerCtx in _mapSid2PlayerCtx)
            {
                lock (playerCtx.Value)
                {
                    foreach (var regItem in playerCtx.Value._registerDict)
                    {
                        if (regItem.Value._serverId == item._serverID)
                        {
                            playerCtx.Value._registerDict.Remove(regItem.Key);
                            StartPlayerShutdown(playerCtx.Value, ServerFrameworkConstDefine.CENTERSERVER_PLAYERCTX_CLOSE_REASON_CRITFAIL);                           
                            break;
                        }
                    }
                }                
            }
        }

        /// <summary>
        /// 静态实例
        /// </summary>
        public static new CenterServerBase Instance
        { get { return (CenterServerBase)(Lava.ServerBase.ServerBase.Instance); } }

        /// <summary>
        /// ServerStateReport Timer ID
        /// </summary>
        protected Int64 _serverStateReportTimerID;

        /// <summary>
        /// PlayerCtxStateReport Timer ID
        /// </summary>
        protected Int64 _playerCtxStateTimerID;

        public IRpcServer FriendServerRpcHandle { get; private set; }

        /// <summary>
        /// serverid到serverinfo的映射
        /// </summary>
        protected ConcurrentDictionary<Int32, CenterServerStateListItem> _mapServerId2State = new ConcurrentDictionary<Int32, CenterServerStateListItem>();

        /// <summary>
        /// sessionid到playercontext的映射
        /// </summary>
        protected ConcurrentDictionary<UInt64, CenterPlayerContext> _mapSid2PlayerCtx = new ConcurrentDictionary<UInt64, CenterPlayerContext>();

        /// <summary>
        /// gameUserId到playercontext的映射
        /// </summary>
        protected ConcurrentDictionary<String, CenterPlayerContext> _mapGameUserId2PlayerCtx = new ConcurrentDictionary<string, CenterPlayerContext>();


    }
}
